import json
import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wait_http(url, timeout=10):
    import urllib.request
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url + "/metrics", timeout=2) as r:
                if r.status == 200:
                    return True
        except Exception:
            pass
        time.sleep(0.2)
    return False


def start_server(tmp_path, port):
    db = tmp_path / "queue.db"
    proc = subprocess.Popen(
        [PY, str(ROOT / "queue_server.py"), str(port), "--db", str(db)],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    assert wait_http(f"http://127.0.0.1:{port}", 10), "server not ready"
    return proc, db


def stop(proc):
    if proc is None:
        return
    try:
        proc.terminate()
        proc.wait(timeout=5)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def post(url, path, data):
    import urllib.request
    req = urllib.request.Request(url + path, data=json.dumps(data).encode(), headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=10) as r:
        return r.status, json.loads(r.read())


def get(url, path):
    import urllib.request
    with urllib.request.urlopen(url + path, timeout=10) as r:
        return r.status, json.loads(r.read())


def start_worker(url, name, seconds=5):
    return subprocess.Popen(
        [PY, str(ROOT / "worker.py"), "--name", name, "--server", url, "--seconds", str(seconds)],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )


def test_two_hundred_jobs(tmp_path):
    port = free_port()
    url = f"http://127.0.0.1:{port}"
    proc, db = start_server(tmp_path, port)
    workers = []
    try:
        for i in range(200):
            st, body = post(url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0.01}})
            assert st == 200 and "id" in body
        for i in range(4):
            workers.append(start_worker(url, f"w{i}", seconds=5))
        deadline = time.time() + 120
        while time.time() < deadline:
            st, m = get(url, "/metrics")
            if m["done"] == 200:
                break
            time.sleep(0.5)
        st, m = get(url, "/metrics")
        assert m["done"] == 200, m
        assert m["dead"] == 0
    finally:
        for w in workers:
            stop(w)
        stop(proc)


def test_sigkill_mid_job(tmp_path):
    port = free_port()
    url = f"http://127.0.0.1:{port}"
    proc, db = start_server(tmp_path, port)
    w = None
    try:
        st, body = post(url, "/jobs", {"kind": "sleep", "payload": {"seconds": 3}})
        jid = body["id"]
        w = start_worker(url, "killer", seconds=10)
        time.sleep(1)
        w.kill()
        w.wait()
        w = None
        # wait for expiry + completion with a new worker
        w2 = start_worker(url, "finisher", seconds=10)
        deadline = time.time() + 60
        while time.time() < deadline:
            st, j = get(url, f"/jobs/{jid}")
            if j["state"] == "done":
                break
            time.sleep(0.5)
        st, j = get(url, f"/jobs/{jid}")
        assert j["state"] == "done", j
        stop(w2)
        w2 = None
    finally:
        if w:
            stop(w)
        stop(proc)


def test_idempotency_409_retries_dead(tmp_path):
    port = free_port()
    url = f"http://127.0.0.1:{port}"
    proc, db = start_server(tmp_path, port)
    try:
        # idempotency
        st1, b1 = post(url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0}, "key": "k1"})
        st2, b2 = post(url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0}, "key": "k1"})
        assert b1["id"] == b2["id"]

        # consume idempotency job if still ready
        try:
            st, lease0 = post(url, "/lease", {"worker": "cleanup", "seconds": 10})
            if lease0.get("id") is not None:
                post(url, f"/jobs/{lease0['id']}/done", {"worker": "cleanup", "result": None})
        except Exception:
            pass

        # 409 rule: lease then another worker done
        st, b = post(url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0}})
        jid = b["id"]
        st, lease = post(url, "/lease", {"worker": "a", "seconds": 10})
        assert lease["id"] == jid
        try:
            post(url, f"/jobs/{jid}/done", {"worker": "b", "result": None})
            raise AssertionError("expected 409")
        except Exception as e:
            import urllib.error
            assert isinstance(e, urllib.error.HTTPError) and e.code == 409

        # finish with a
        post(url, f"/jobs/{jid}/done", {"worker": "a", "result": "ok"})
        st, j = get(url, f"/jobs/{jid}")
        assert j["state"] == "done" and j["result"] == "ok"

        # retries + dead
        st, b = post(url, "/jobs", {"kind": "fail_n", "payload": {"n": 2}, "max_attempts": 5})
        jid2 = b["id"]
        w = start_worker(url, "r1", seconds=5)
        deadline = time.time() + 60
        while time.time() < deadline:
            st, j = get(url, f"/jobs/{jid2}")
            if j["state"] == "done":
                break
            time.sleep(0.5)
        st, j = get(url, f"/jobs/{jid2}")
        assert j["state"] == "done", j
        assert j["attempts"] == 3, j
        stop(w)

        # dead
        st, b = post(url, "/jobs", {"kind": "fail_n", "payload": {"n": 10}, "max_attempts": 2})
        jid3 = b["id"]
        w = start_worker(url, "r2", seconds=5)
        deadline = time.time() + 60
        while time.time() < deadline:
            st, j = get(url, f"/jobs/{jid3}")
            if j["state"] == "dead":
                break
            time.sleep(0.5)
        st, j = get(url, f"/jobs/{jid3}")
        assert j["state"] == "dead", j
        assert j["attempts"] == 2, j
        stop(w)
    finally:
        stop(proc)


def test_server_restart_keeps_state(tmp_path):
    port = free_port()
    url = f"http://127.0.0.1:{port}"
    proc, db = start_server(tmp_path, port)
    try:
        for i in range(5):
            post(url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0.1}})
        # kill server
        stop(proc)
        proc = None
        # restart
        proc2, _ = start_server(tmp_path, port)
        proc = proc2
        # state preserved: 5 ready
        st, m = get(url, "/metrics")
        assert m["ready"] + m["leased"] + m["done"] == 5, m
        # run workers
        ws = [start_worker(url, f"rw{i}", seconds=5) for i in range(2)]
        deadline = time.time() + 60
        while time.time() < deadline:
            st, m = get(url, "/metrics")
            if m["done"] == 5:
                break
            time.sleep(0.5)
        st, m = get(url, "/metrics")
        assert m["done"] == 5, m
        for w in ws:
            stop(w)
    finally:
        stop(proc)
