# Durable Job Queue

SQLite-backed HTTP job queue (stdlib only).

## Full jitter backoff

Researched from AWS Architecture Blog, "Exponential Backoff And Jitter"
(https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/).

Formula as implemented (in `queue_server.py`):

```
delay = random.uniform(0, min(60.0, 1.0 * 2 ** attempts))
```

where `attempts` is the number of attempts already made for the job. This is the
"Full Jitter" strategy: `sleep = random(0, min(cap, base * 2 ** attempt))`.
