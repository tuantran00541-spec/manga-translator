#!/usr/bin/env python3
"""Job queue worker."""

import argparse
import hashlib
import json
import os
import time
import urllib.request
import urllib.error

DEFAULT_SERVER = "http://127.0.0.1:8091"


def http_post(url, path, data):
    req = urllib.request.Request(url.rstrip("/") + path, data=json.dumps(data).encode(), headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read()
        if not raw:
            return resp.status, None
        return resp.status, json.loads(raw.decode())


def http_get(url, path):
    req = urllib.request.Request(url.rstrip("/") + path, method="GET")
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read()
        if not raw:
            return resp.status, None
        return resp.status, json.loads(raw.decode())


def parse_server(args):
    server = args.server
    if server is None and args.positional:
        # first positional could be name or url
        for p in args.positional:
            if p.startswith("http://") or p.startswith("https://"):
                server = p
    if server is None:
        port = args.port
        if port is None and args.positional:
            for p in args.positional:
                if p.isdigit():
                    port = int(p)
        if port is not None:
            server = f"http://127.0.0.1:{port}"
    if server is None:
        server = os.environ.get("SERVER_URL") or os.environ.get("QUEUE_SERVER") or DEFAULT_SERVER
    return server


def parse_name(args):
    name = args.name
    if name is None and args.positional:
        for p in args.positional:
            if not (p.startswith("http://") or p.startswith("https://")):
                # could be port? skip digits
                if not p.isdigit():
                    name = p
                    break
    if name is None:
        name = os.environ.get("WORKER_NAME") or f"worker-{os.getpid()}"
    return name


def fail_threshold(payload):
    for key in ("n", "failures", "fail_n", "failures_count", "count", "times", "num_failures", "failure_count", "max_failures", "failures_n"):
        if key in (payload or {}):
            try:
                return int(payload[key])
            except Exception:
                pass
    return 0


def run_job(job):
    kind = job["kind"]
    payload = job.get("payload") or {}
    attempts = job.get("attempts", 1)
    if kind == "sleep":
        seconds = payload.get("seconds", 0)
        time.sleep(float(seconds))
        return {"slept": seconds}
    if kind == "fail_n":
        n = fail_threshold(payload)
        if attempts <= n:
            raise RuntimeError(f"intentional failure attempt {attempts}/{n}")
        return {"ok": True, "attempts": attempts}
    if kind == "hash":
        text = payload.get("text", "")
        times = int(payload.get("times", 1))
        data = text * times
        return hashlib.sha256(data.encode()).hexdigest()
    # unknown kind: succeed
    return {"unknown_kind": kind}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("positional", nargs="*")
    parser.add_argument("--name", "--worker", dest="name", default=None)
    parser.add_argument("--server", "--url", dest="server", default=None)
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--seconds", "--lease-seconds", dest="seconds", type=float, default=20.0)
    parser.add_argument("--poll", type=float, default=0.2)
    args = parser.parse_args()

    name = parse_name(args)
    server = parse_server(args)
    print(f"worker {name} -> {server}", flush=True)

    while True:
        try:
            status, body = http_post(server, "/lease", {"worker": name, "seconds": args.seconds})
        except Exception as e:
            print("lease error", e, flush=True)
            time.sleep(1)
            continue
        if not body or body.get("id") is None:
            time.sleep(args.poll)
            continue
        job = body.get("job") or body
        jid = job["id"]
        try:
            result = run_job(job)
            http_post(server, f"/jobs/{jid}/done", {"worker": name, "result": result})
        except Exception as e:
            try:
                http_post(server, f"/jobs/{jid}/fail", {"worker": name, "error": str(e)})
            except Exception as e2:
                print("fail error", e2, flush=True)


if __name__ == "__main__":
    main()
