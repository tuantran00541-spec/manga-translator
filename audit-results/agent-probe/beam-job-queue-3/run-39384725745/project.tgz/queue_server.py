#!/usr/bin/env python3
"""Durable SQLite-backed job queue HTTP server."""

import argparse
import json
import os
import random
import sqlite3
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

DEFAULT_PORT = 8091
DEFAULT_DB = "queue.db"

BASE_BACKOFF = 1.0
CAP_BACKOFF = 60.0

STATES = ("ready", "leased", "done", "failed-waiting", "dead")


def db_path_from_args():
    return None


def connect(db_path):
    conn = sqlite3.connect(db_path, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def init_db(db_path):
    conn = connect(db_path)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kind TEXT NOT NULL,
            payload TEXT NOT NULL,
            max_attempts INTEGER NOT NULL,
            key TEXT UNIQUE,
            state TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            result TEXT,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL,
            next_run_at REAL,
            leased_worker TEXT,
            lease_token INTEGER NOT NULL DEFAULT 0,
            lease_until REAL,
            finished_at REAL
        )
        """
    )
    conn.commit()
    conn.close()


def now():
    return time.time()


def external_state(row):
    st = row["state"]
    if st == "failed-waiting":
        nra = row["next_run_at"]
        if nra is None or nra <= time.time():
            return "ready"
        return "failed-waiting"
    if st == "leased":
        lu = row["lease_until"]
        if lu is not None and lu <= time.time():
            return "ready"
        return "leased"
    return st


def row_to_job(row):
    if row is None:
        return None
    try:
        payload = json.loads(row["payload"]) if row["payload"] is not None else None
    except Exception:
        payload = row["payload"]
    result_raw = row["result"]
    try:
        result = json.loads(result_raw) if result_raw is not None else None
    except Exception:
        result = result_raw
    return {
        "id": row["id"],
        "kind": row["kind"],
        "payload": payload,
        "max_attempts": row["max_attempts"],
        "key": row["key"],
        "state": external_state(row),
        "internal_state": row["state"],
        "attempts": row["attempts"],
        "last_error": row["last_error"],
        "result": result,
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
        "next_run_at": row["next_run_at"],
        "leased_worker": row["leased_worker"],
        "lease_token": row["lease_token"],
        "lease_until": row["lease_until"],
        "finished_at": row["finished_at"],
    }


class Handler(BaseHTTPRequestHandler):
    db_path = DEFAULT_DB

    def _send(self, status, obj=None, extra_headers=None):
        body = b""
        if obj is not None:
            body = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        if body:
            self.wfile.write(body)

    def _read_json(self):
        n = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(n) if n > 0 else b""
        if not raw:
            return {}
        return json.loads(raw.decode())

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        if path.startswith("/jobs/"):
            try:
                jid = int(path.split("/")[2])
            except Exception:
                self._send(404, {"error": "not found"})
                return
            conn = connect(self.db_path)
            try:
                row = conn.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
            finally:
                conn.close()
            if row is None:
                self._send(404, {"error": "not found"})
                return
            self._send(200, row_to_job(row))
            return
        if path == "/metrics":
            conn = connect(self.db_path)
            try:
                rows = conn.execute("SELECT * FROM jobs").fetchall()
            finally:
                conn.close()
            counts = {s: 0 for s in STATES}
            durations = []
            for r in rows:
                st = external_state(r)
                if st in counts:
                    counts[st] += 1
                if r["state"] == "done" and r["finished_at"] is not None:
                    durations.append(r["finished_at"] - r["created_at"])
            durations.sort()
            p50 = percentile(durations, 50)
            p95 = percentile(durations, 95)
            resp = {
                "counts": counts,
                "states": dict(counts),
                "ready": counts["ready"],
                "leased": counts["leased"],
                "done": counts["done"],
                "failed-waiting": counts["failed-waiting"],
                "dead": counts["dead"],
                "p50": p50,
                "p95": p95,
                "p50_seconds": p50,
                "p95_seconds": p95,
                "latency_p50_seconds": p50,
                "latency_p95_seconds": p95,
                "total": len(rows),
            }
            self._send(200, resp)
            return
        self._send(404, {"error": "not found"})

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        try:
            data = self._read_json()
        except Exception:
            self._send(400, {"error": "bad json"})
            return

        # POST /jobs
        if path == "/jobs":
            kind = data.get("kind")
            payload = data.get("payload", {})
            max_attempts = data.get("max_attempts", 5)
            key = data.get("key")
            if kind is None:
                self._send(400, {"error": "kind required"})
                return
            try:
                max_attempts = int(max_attempts)
            except Exception:
                self._send(400, {"error": "bad max_attempts"})
                return
            if max_attempts < 1:
                max_attempts = 1
            conn = connect(self.db_path)
            try:
                conn.execute("BEGIN IMMEDIATE")
                if key is not None:
                    existing = conn.execute("SELECT id FROM jobs WHERE key=?", (key,)).fetchone()
                    if existing is not None:
                        conn.commit()
                        self._send(200, {"id": existing["id"]})
                        return
                t = now()
                cur = conn.execute(
                    "INSERT INTO jobs (kind, payload, max_attempts, key, state, attempts, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)",
                    (kind, json.dumps(payload), max_attempts, key, "ready", 0, t, t),
                )
                jid = cur.lastrowid
                conn.commit()
            except sqlite3.IntegrityError:
                conn.rollback()
                # race on key
                if key is not None:
                    existing = conn.execute("SELECT id FROM jobs WHERE key=?", (key,)).fetchone()
                    if existing is not None:
                        self._send(200, {"id": existing["id"]})
                        return
                self._send(409, {"error": "conflict"})
                return
            except Exception as e:
                conn.rollback()
                self._send(500, {"error": str(e)})
                return
            finally:
                conn.close()
            self._send(200, {"id": jid})
            return

        # POST /lease
        if path == "/lease":
            worker = data.get("worker")
            seconds = data.get("seconds", 10)
            try:
                seconds = float(seconds)
            except Exception:
                seconds = 10.0
            if seconds <= 0:
                seconds = 1.0
            t = now()
            lease_until = t + seconds
            conn = connect(self.db_path)
            try:
                conn.execute("BEGIN IMMEDIATE")
                row = conn.execute(
                    """
                    SELECT id FROM jobs
                    WHERE
                      state='ready'
                      OR (state='failed-waiting' AND COALESCE(next_run_at,0) <= ?)
                      OR (state='leased' AND COALESCE(lease_until,0) <= ?)
                    ORDER BY created_at ASC, id ASC
                    LIMIT 1
                    """,
                    (t, t),
                ).fetchone()
                if row is None:
                    conn.commit()
                    self._send(200, {"id": None, "job": None})
                    return
                jid = row["id"]
                # increment lease_token and attempts
                conn.execute(
                    """
                    UPDATE jobs
                    SET state='leased',
                        leased_worker=?,
                        lease_token=lease_token+1,
                        lease_until=?,
                        attempts=attempts+1,
                        updated_at=?,
                        next_run_at=NULL
                    WHERE id=?
                    """,
                    (worker, lease_until, t, jid),
                )
                conn.commit()
            except Exception as e:
                conn.rollback()
                self._send(500, {"error": str(e)})
                return
            finally:
                conn.close()
            # fetch updated
            conn = connect(self.db_path)
            try:
                row = conn.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
            finally:
                conn.close()
            job = row_to_job(row)
            resp = {
                "id": job["id"],
                "kind": job["kind"],
                "payload": job["payload"],
                "max_attempts": job["max_attempts"],
                "attempts": job["attempts"],
                "lease_token": job["lease_token"],
                "worker": worker,
                "lease_until": job["lease_until"],
                "job": job,
            }
            self._send(200, resp)
            return

        # POST /jobs/<id>/done or /fail
        parts = path.split("/")
        # /jobs/<id>/done
        if len(parts) == 4 and parts[1] == "jobs" and parts[3] in ("done", "fail"):
            try:
                jid = int(parts[2])
            except Exception:
                self._send(404, {"error": "not found"})
                return
            action = parts[3]
            worker = data.get("worker")
            conn = connect(self.db_path)
            try:
                conn.execute("BEGIN IMMEDIATE")
                row = conn.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
                if row is None:
                    conn.commit()
                    self._send(404, {"error": "not found"})
                    return
                # validate lease
                valid = (
                    row["state"] == "leased"
                    and row["leased_worker"] == worker
                    and row["lease_until"] is not None
                    and row["lease_until"] > now()
                )
                if not valid:
                    conn.commit()
                    self._send(409, {"error": "not lease holder"})
                    return
                t = now()
                if action == "done":
                    result = data.get("result")
                    conn.execute(
                        "UPDATE jobs SET state='done', result=?, leased_worker=NULL, lease_until=NULL, finished_at=?, updated_at=? WHERE id=?",
                        (json.dumps(result), t, t, jid),
                    )
                else:
                    error = data.get("error")
                    attempts = row["attempts"]
                    max_attempts = row["max_attempts"]
                    if attempts >= max_attempts:
                        conn.execute(
                            "UPDATE jobs SET state='dead', last_error=?, leased_worker=NULL, lease_until=NULL, updated_at=? WHERE id=?",
                            (str(error) if error is not None else None, t, jid),
                        )
                    else:
                        delay = random.uniform(0, min(CAP_BACKOFF, BASE_BACKOFF * (2 ** attempts)))
                        next_run = t + delay
                        conn.execute(
                            "UPDATE jobs SET state='failed-waiting', last_error=?, leased_worker=NULL, lease_until=NULL, next_run_at=?, updated_at=? WHERE id=?",
                            (str(error) if error is not None else None, next_run, t, jid),
                        )
                conn.commit()
            except Exception as e:
                conn.rollback()
                self._send(500, {"error": str(e)})
                return
            finally:
                conn.close()
            self._send(200, {"ok": True, "id": jid})
            return

        self._send(404, {"error": "not found"})


def percentile(vals, p):
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    # linear interpolation
    k = (len(vals) - 1) * (p / 100.0)
    f = int(k)
    c = min(f + 1, len(vals) - 1)
    if f == c:
        return vals[f]
    return vals[f] + (vals[c] - vals[f]) * (k - f)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("port_positional", nargs="?", default=None)
    parser.add_argument("--port", "-p", type=int, default=None)
    parser.add_argument("--db", default=None)
    args = parser.parse_args()

    port = DEFAULT_PORT
    db_path = args.db
    positionals = []
    if args.port_positional is not None:
        positionals.append(args.port_positional)
    # collect any extra positionals? argparse only one. Handle space-separated via env? no.
    # Determine port/db from positional
    if db_path is None:
        db_path = os.environ.get("DB_PATH") or os.environ.get("QUEUE_DB") or DEFAULT_DB
    if positionals:
        for p0 in positionals:
            if p0.isdigit():
                port = int(p0) if args.port is None else port
            else:
                db_path = p0
    if args.port is None and os.environ.get("PORT"):
        try:
            port = int(os.environ["PORT"])
        except ValueError:
            pass
    if args.port is not None:
        port = args.port

    os.environ.setdefault("QUEUE_DB_PATH", db_path)
    init_db(db_path)

    httpd = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    httpd.allow_reuse_address = True
    Handler.db_path = db_path
    print(f"queue_server listening on {port} db={db_path}", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
