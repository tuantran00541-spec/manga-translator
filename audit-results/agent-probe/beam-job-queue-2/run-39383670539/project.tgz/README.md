# Durable Job Queue

SQLite-backed HTTP job queue (Python stdlib only).

## Full jitter backoff

Formula as implemented (AWS "Exponential Backoff And Jitter", Full Jitter):

```
temp = min(cap, base * 2 ** attempt)
sleep = random.uniform(0, temp)   # random in [0, temp)
```

with `base = 1.0`, `cap = 60.0`, and `attempt` = current attempt number of the failed job.

Source: https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/
(See the "Full Jitter" definition: `temp = min(cap, base * 2 ** attempt)` then `sleep = random.randrange(0, temp)`.)

## Run server

```
python3 queue_server.py            # port 8091, queue.db
python3 queue_server.py 8092 /tmp/q.db
python3 queue_server.py --port 8092 --db /tmp/q.db
```

## Run worker

```
python3 worker.py                 # connects to 127.0.0.1:8091
python3 worker.py w1 --server http://127.0.0.1:8091
```
