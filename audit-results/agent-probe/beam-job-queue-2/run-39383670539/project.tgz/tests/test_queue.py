import json
import os
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SERVER = str(ROOT / "queue_server.py")
WORKER = str(ROOT / "worker.py")
PYBIN = sys.executable


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def wait_http(url, timeout=10):
    import urllib.request
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url + "/health", timeout=1) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.2)
    return False


def start_server(port, db):
    proc = subprocess.Popen(
        [PYBIN, SERVER, "--port", str(port), "--db", str(db)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    url = f"http://127.0.0.1:{port}"
    assert wait_http(url, 10), "server not ready"
    return proc, url


def stop_proc(proc, sig=signal.SIGTERM, wait=10):
    if proc.poll() is None:
        proc.send_signal(sig)
        try:
            proc.wait(timeout=wait)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()


def http(method, url, path, body=None):
    import urllib.request, urllib.error
    data = None
    headers = {}
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = r.read()
            return r.status, json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw) if raw else {}
        except Exception:
            return e.code, {"error": raw.decode("utf-8", "ignore")}


def test_basic_flow():
    port = free_port()
    db = f"/tmp/scratchpad/t_{port}.db"
    Path(db).unlink(missing_ok=True)
    proc, url = start_server(port, db)
    try:
        st, r = http("POST", url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0.01}, "max_attempts": 2})
        assert st == 200
        jid = r["id"]
        st, job = http("GET", url, f"/jobs/{jid}")
        assert job["state"] == "ready"
        st, lease = http("POST", url, "/lease", {"worker": "w1", "seconds": 5})
        assert st == 200 and (lease.get("job") or lease)["id"] == jid
        st, r = http("POST", url, f"/jobs/{jid}/done", {"worker": "w1", "result": {"ok": True}})
        assert st == 200
        st, job = http("GET", url, f"/jobs/{jid}")
        assert job["state"] == "done"
        assert job["result"] == {"ok": True}
    finally:
        stop_proc(proc)


def test_idempotency():
    port = free_port()
    db = f"/tmp/scratchpad/t_{port}.db"
    Path(db).unlink(missing_ok=True)
    proc, url = start_server(port, db)
    try:
        st, r1 = http("POST", url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0}, "key": "k1"})
        st, r2 = http("POST", url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0}, "key": "k1"})
        assert r1["id"] == r2["id"]
    finally:
        stop_proc(proc)


def test_409():
    port = free_port()
    db = f"/tmp/scratchpad/t_{port}.db"
    Path(db).unlink(missing_ok=True)
    proc, url = start_server(port, db)
    try:
        st, r = http("POST", url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0}})
        jid = r["id"]
        http("POST", url, "/lease", {"worker": "a", "seconds": 5})
        st, r = http("POST", url, f"/jobs/{jid}/done", {"worker": "b", "result": None})
        assert st == 409
        st, r = http("POST", url, f"/jobs/{jid}/fail", {"worker": "b", "error": "x"})
        assert st == 409
    finally:
        stop_proc(proc)


def test_dead_and_retries():
    port = free_port()
    db = f"/tmp/scratchpad/t_{port}.db"
    Path(db).unlink(missing_ok=True)
    proc, url = start_server(port, db)
    try:
        # max_attempts=2, fail_n n=10 -> dead after 2
        st, r = http("POST", url, "/jobs", {"kind": "fail_n", "payload": {"n": 10}, "max_attempts": 2})
        jid = r["id"]
        # run a worker
        w = subprocess.Popen([PYBIN, WORKER, "w", "--server", url, "--lease-seconds", "2", "--poll", "0.2"])
        deadline = time.time() + 30
        while time.time() < deadline:
            st, job = http("GET", url, f"/jobs/{jid}")
            if job["state"] in ("dead", "done"):
                break
            time.sleep(0.5)
        stop_proc(w)
        st, job = http("GET", url, f"/jobs/{jid}")
        assert job["state"] == "dead", job
        assert job["attempts"] == 2
    finally:
        stop_proc(proc)


def test_fail_n_succeeds():
    port = free_port()
    db = f"/tmp/scratchpad/t_{port}.db"
    Path(db).unlink(missing_ok=True)
    proc, url = start_server(port, db)
    try:
        st, r = http("POST", url, "/jobs", {"kind": "fail_n", "payload": {"n": 2}, "max_attempts": 5})
        jid = r["id"]
        w = subprocess.Popen([PYBIN, WORKER, "w", "--server", url, "--lease-seconds", "2", "--poll", "0.2"])
        deadline = time.time() + 60
        while time.time() < deadline:
            st, job = http("GET", url, f"/jobs/{jid}")
            if job["state"] in ("done", "dead"):
                break
            time.sleep(0.5)
        stop_proc(w)
        st, job = http("GET", url, f"/jobs/{jid}")
        assert job["state"] == "done", job
        assert job["attempts"] == 3
    finally:
        stop_proc(proc)


def test_200_jobs_4_workers():
    port = free_port()
    db = f"/tmp/scratchpad/t_{port}.db"
    Path(db).unlink(missing_ok=True)
    proc, url = start_server(port, db)
    try:
        ids = []
        for i in range(200):
            st, r = http("POST", url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0.02}})
            ids.append(r["id"])
        workers = []
        for i in range(4):
            workers.append(subprocess.Popen([PYBIN, WORKER, f"w{i}", "--server", url, "--lease-seconds", "5", "--poll", "0.1"]))
        deadline = time.time() + 120
        while time.time() < deadline:
            st, m = http("GET", url, "/metrics")
            if m.get("done", 0) >= 200:
                break
            time.sleep(1)
        for w in workers:
            stop_proc(w)
        st, m = http("GET", url, "/metrics")
        assert m["done"] == 200, m
        # all done
        for jid in ids:
            st, job = http("GET", url, f"/jobs/{jid}")
            assert job["state"] == "done", (jid, job["state"])
    finally:
        stop_proc(proc)


def test_sigkill_mid_job():
    port = free_port()
    db = f"/tmp/scratchpad/t_{port}.db"
    Path(db).unlink(missing_ok=True)
    proc, url = start_server(port, db)
    try:
        st, r = http("POST", url, "/jobs", {"kind": "sleep", "payload": {"seconds": 5}})
        jid = r["id"]
        w1 = subprocess.Popen([PYBIN, WORKER, "w1", "--server", url, "--lease-seconds", "1", "--poll", "0.1"])
        # wait until leased
        deadline = time.time() + 5
        while time.time() < deadline:
            st, job = http("GET", url, f"/jobs/{jid}")
            if job["state"] == "leased":
                break
            time.sleep(0.2)
        # kill
        w1.send_signal(signal.SIGKILL)
        w1.wait()
        # wait for expiry
        time.sleep(1.5)
        w2 = subprocess.Popen([PYBIN, WORKER, "w2", "--server", url, "--lease-seconds", "10", "--poll", "0.1"])
        deadline = time.time() + 20
        while time.time() < deadline:
            st, job = http("GET", url, f"/jobs/{jid}")
            if job["state"] == "done":
                break
            time.sleep(0.5)
        stop_proc(w2)
        st, job = http("GET", url, f"/jobs/{jid}")
        assert job["state"] == "done", job
    finally:
        stop_proc(proc)


def test_server_restart():
    port = free_port()
    db = f"/tmp/scratchpad/t_{port}.db"
    Path(db).unlink(missing_ok=True)
    proc, url = start_server(port, db)
    st, r = http("POST", url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0}})
    jid = r["id"]
    stop_proc(proc)
    # restart
    proc2, url2 = start_server(port, db)
    try:
        st, job = http("GET", url2, f"/jobs/{jid}")
        assert st == 200
        assert job["id"] == jid
    finally:
        stop_proc(proc2)


def test_metrics_p95():
    port = free_port()
    db = f"/tmp/scratchpad/t_{port}.db"
    Path(db).unlink(missing_ok=True)
    proc, url = start_server(port, db)
    try:
        for i in range(5):
            http("POST", url, "/jobs", {"kind": "sleep", "payload": {"seconds": 0}})
        w = subprocess.Popen([PYBIN, WORKER, "w", "--server", url, "--lease-seconds", "5", "--poll", "0.1"])
        deadline = time.time() + 30
        while time.time() < deadline:
            st, m = http("GET", url, "/metrics")
            if m.get("done", 0) >= 5:
                break
            time.sleep(0.5)
        stop_proc(w)
        st, m = http("GET", url, "/metrics")
        assert m["p50_seconds"] is not None
    finally:
        stop_proc(proc)
