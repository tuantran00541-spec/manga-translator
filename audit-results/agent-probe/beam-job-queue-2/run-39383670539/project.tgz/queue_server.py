#!/usr/bin/env python3
import argparse
import http.server
import json
import os
import random
import re
import sqlite3
import threading
import time
import urllib.parse

STATE_NAMES = ["ready", "leased", "done", "failed-waiting", "dead"]

DB_PATH = None
DB_INSTANCE = None
DB_LOCK = threading.Lock()


def db_path_from_env():
    return os.environ.get("QUEUE_DB") or os.environ.get("DB_PATH") or "queue.db"


def connect(db_path):
    conn = sqlite3.connect(db_path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=30000")
    try:
        conn.execute("PRAGMA journal_mode=WAL")
    except sqlite3.DatabaseError:
        pass
    return conn


SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    max_attempts INTEGER NOT NULL DEFAULT 5,
    attempts INTEGER NOT NULL DEFAULT 0,
    key TEXT UNIQUE,
    state TEXT NOT NULL,
    worker TEXT,
    lease_expires REAL,
    retry_at REAL,
    result TEXT,
    last_error TEXT,
    created_at REAL NOT NULL,
    done_at REAL,
    updated_at REAL NOT NULL
);
"""


def init_db(db_path):
    conn = connect(db_path)
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


def now():
    return time.time()


def row_to_job(row):
    if row is None:
        return None
    result_raw = row["result"]
    try:
        result = json.loads(result_raw) if result_raw is not None else None
    except (json.JSONDecodeError, TypeError):
        result = result_raw
    payload_raw = row["payload"]
    try:
        payload = json.loads(payload_raw) if payload_raw is not None else None
    except (json.JSONDecodeError, TypeError):
        payload = payload_raw
    return {
        "id": row["id"],
        "kind": row["kind"],
        "payload": payload,
        "max_attempts": row["max_attempts"],
        "attempts": row["attempts"],
        "key": row["key"],
        "state": row["state"],
        "worker": row["worker"],
        "lease_expires": row["lease_expires"],
        "retry_at": row["retry_at"],
        "result": result,
        "last_error": row["last_error"],
        "created_at": row["created_at"],
        "done_at": row["done_at"],
        "updated_at": row["updated_at"],
    }


def refresh_ready(conn, t=None):
    if t is None:
        t = now()
    conn.execute(
        "UPDATE jobs SET state='ready', worker=NULL, lease_expires=NULL, updated_at=? "
        "WHERE state='leased' AND lease_expires IS NOT NULL AND lease_expires <= ?",
        (t, t),
    )
    conn.execute(
        "UPDATE jobs SET state='ready', updated_at=? "
        "WHERE state='failed-waiting' AND retry_at IS NOT NULL AND retry_at <= ?",
        (t, t),
    )


def backoff_delay(attempt):
    base = 1.0
    cap = 60.0
    temp = min(cap, base * (2 ** attempt))
    return random.uniform(0.0, temp)


def get_db_path():
    global DB_PATH
    if DB_PATH is None:
        DB_PATH = db_path_from_env()
    return DB_PATH


class DB:
    def __init__(self, db_path):
        self.db_path = db_path

    def connect(self):
        return connect(self.db_path)

    def create_job(self, kind, payload, max_attempts, key):
        conn = self.connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            t = now()
            if key is not None:
                row = conn.execute("SELECT id FROM jobs WHERE key=?", (key,)).fetchone()
                if row is not None:
                    jid = row["id"]
                    conn.commit()
                    return jid
            cur = conn.execute(
                "INSERT INTO jobs (kind, payload, max_attempts, attempts, key, state, "
                "created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)",
                (kind, json.dumps(payload), int(max_attempts), 0, key, "ready", t, t),
            )
            jid = cur.lastrowid
            conn.commit()
            return jid
        except sqlite3.IntegrityError:
            conn.rollback()
            conn2 = self.connect()
            try:
                conn2.execute("BEGIN IMMEDIATE")
                row = conn2.execute("SELECT id FROM jobs WHERE key=?", (key,)).fetchone()
                jid = row["id"] if row is not None else None
                conn2.commit()
                return jid
            finally:
                conn2.close()
        finally:
            conn.close()

    def lease(self, worker, seconds):
        with DB_LOCK:
            conn = self.connect()
            try:
                conn.execute("BEGIN IMMEDIATE")
                t = now()
                refresh_ready(conn, t)
                row = conn.execute(
                    "SELECT id, attempts, max_attempts FROM jobs "
                    "WHERE state='ready' ORDER BY created_at ASC, id ASC LIMIT 1"
                ).fetchone()
                if row is None:
                    conn.commit()
                    return None
                job_id = row["id"]
                new_attempts = row["attempts"] + 1
                expiry = t + float(seconds)
                conn.execute(
                    "UPDATE jobs SET state='leased', worker=?, lease_expires=?, "
                    "attempts=?, updated_at=? WHERE id=?",
                    (worker, expiry, new_attempts, t, job_id),
                )
                r = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
                job = row_to_job(r)
                conn.commit()
                return job
            finally:
                conn.close()

    def get_job(self, job_id):
        conn = self.connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            t = now()
            refresh_ready(conn, t)
            r = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            conn.commit()
            return row_to_job(r)
        finally:
            conn.close()

    def finish_done(self, job_id, worker, result):
        conn = self.connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            t = now()
            refresh_ready(conn, t)
            r = conn.execute(
                "SELECT state, worker, lease_expires FROM jobs WHERE id=?", (job_id,)
            ).fetchone()
            if r is None:
                conn.commit()
                return False, "not_found"
            if r["state"] != "leased" or r["worker"] != worker:
                conn.commit()
                return False, "not_holder"
            if r["lease_expires"] is not None and r["lease_expires"] < t:
                conn.commit()
                return False, "expired"
            conn.execute(
                "UPDATE jobs SET state='done', result=?, done_at=?, worker=?, "
                "lease_expires=NULL, updated_at=? WHERE id=?",
                (json.dumps(result), t, worker, t, job_id),
            )
            conn.commit()
            return True, "ok"
        finally:
            conn.close()

    def finish_fail(self, job_id, worker, error):
        conn = self.connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            t = now()
            refresh_ready(conn, t)
            r = conn.execute(
                "SELECT state, worker, lease_expires, attempts, max_attempts FROM jobs WHERE id=?",
                (job_id,),
            ).fetchone()
            if r is None:
                conn.commit()
                return False, "not_found"
            if r["state"] != "leased" or r["worker"] != worker:
                conn.commit()
                return False, "not_holder"
            if r["lease_expires"] is not None and r["lease_expires"] < t:
                conn.commit()
                return False, "expired"
            attempts = r["attempts"]
            max_attempts = r["max_attempts"]
            if attempts >= max_attempts:
                conn.execute(
                    "UPDATE jobs SET state='dead', last_error=?, worker=?, "
                    "lease_expires=NULL, updated_at=? WHERE id=?",
                    (str(error), worker, t, job_id),
                )
            else:
                delay = backoff_delay(attempts)
                retry_at = t + delay
                conn.execute(
                    "UPDATE jobs SET state='failed-waiting', last_error=?, worker=NULL, "
                    "lease_expires=NULL, retry_at=?, updated_at=? WHERE id=?",
                    (str(error), retry_at, t, job_id),
                )
            conn.commit()
            return True, "ok"
        finally:
            conn.close()

    def metrics(self):
        conn = self.connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            t = now()
            refresh_ready(conn, t)
            rows = conn.execute("SELECT state FROM jobs").fetchall()
            counts = {s: 0 for s in STATE_NAMES}
            for row in rows:
                st = row["state"]
                if st in counts:
                    counts[st] += 1
                else:
                    counts[st] = counts.get(st, 0) + 1
            done_rows = conn.execute(
                "SELECT created_at, done_at FROM jobs WHERE state='done' AND done_at IS NOT NULL"
            ).fetchall()
            durations = sorted(r["done_at"] - r["created_at"] for r in done_rows)
            p50 = percentile(durations, 50)
            p95 = percentile(durations, 95)
            conn.commit()
            return counts, p50, p95, len(durations)
        finally:
            conn.close()


def percentile(sorted_vals, p):
    if not sorted_vals:
        return None
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    k = (len(sorted_vals) - 1) * (p / 100.0)
    f = int(k)
    c = min(f + 1, len(sorted_vals) - 1)
    if f == c:
        return sorted_vals[f]
    return sorted_vals[f] + (sorted_vals[c] - sorted_vals[f]) * (k - f)


def get_db():
    global DB_INSTANCE
    if DB_INSTANCE is None:
        DB_INSTANCE = DB(get_db_path())
        init_db(get_db_path())
    return DB_INSTANCE


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send(self, status, obj):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        raw = self.rfile.read(length) if length else b""
        if not raw:
            return {}
        return json.loads(raw.decode("utf-8"))

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/")
        db = get_db()
        if path == "/health":
            self._send(200, {"ok": True})
            return
        if path == "/metrics":
            counts, p50, p95, n = db.metrics()
            resp = {
                "counts": counts,
                "states": dict(counts),
            }
            for s in STATE_NAMES:
                resp[s] = counts.get(s, 0)
            resp.update({
                "p50": p50,
                "p95": p95,
                "p50_seconds": p50,
                "p95_seconds": p95,
                "latency_p50_seconds": p50,
                "latency_p95_seconds": p95,
                "done_count": n,
                "total": sum(counts.values()),
            })
            self._send(200, resp)
            return
        m = re.match(r"^/jobs/(\d+)$", path)
        if m:
            job_id = int(m.group(1))
            job = db.get_job(job_id)
            if job is None:
                self._send(404, {"error": "not found"})
                return
            self._send(200, job)
            return
        self._send(404, {"error": "not found"})

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/")
        db = get_db()
        try:
            body = self._read_json()
        except Exception:
            self._send(400, {"error": "bad json"})
            return
        if path == "/jobs":
            kind = body.get("kind")
            payload = body.get("payload", {})
            if payload is None:
                payload = {}
            max_attempts = body.get("max_attempts", 5)
            key = body.get("key", None)
            if not kind:
                self._send(400, {"error": "kind required"})
                return
            try:
                max_attempts = int(max_attempts)
            except (TypeError, ValueError):
                self._send(400, {"error": "bad max_attempts"})
                return
            if max_attempts < 1:
                max_attempts = 1
            jid = db.create_job(kind, payload, max_attempts, key)
            self._send(200, {"id": jid})
            return
        if path == "/lease":
            worker = body.get("worker")
            seconds = body.get("seconds", 30)
            if not worker:
                self._send(400, {"error": "worker required"})
                return
            try:
                seconds = float(seconds)
            except (TypeError, ValueError):
                self._send(400, {"error": "bad seconds"})
                return
            if seconds <= 0:
                seconds = 1
            job = db.lease(worker, seconds)
            if job is None:
                self._send(200, {"job": None})
                return
            resp = dict(job)
            resp["job"] = job
            self._send(200, resp)
            return
        m = re.match(r"^/jobs/(\d+)/done$", path)
        if m:
            job_id = int(m.group(1))
            worker = body.get("worker")
            result = body.get("result", None)
            ok, msg = db.finish_done(job_id, worker, result)
            if not ok:
                status = 404 if msg == "not_found" else 409
                self._send(status, {"error": msg, "ok": False})
                return
            self._send(200, {"ok": True})
            return
        m = re.match(r"^/jobs/(\d+)/fail$", path)
        if m:
            job_id = int(m.group(1))
            worker = body.get("worker")
            error = body.get("error", "")
            ok, msg = db.finish_fail(job_id, worker, error)
            if not ok:
                status = 404 if msg == "not_found" else 409
                self._send(status, {"error": msg, "ok": False})
                return
            self._send(200, {"ok": True})
            return
        self._send(404, {"error": "not found"})

    def log_message(self, *args):
        pass


def main():
    global DB_PATH, DB_INSTANCE
    parser = argparse.ArgumentParser()
    parser.add_argument("port_positional", nargs="?", type=int, default=None)
    parser.add_argument("db_positional", nargs="?", default=None)
    parser.add_argument("--host", default=os.environ.get("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--db", default=None)
    args = parser.parse_args()

    port = args.port
    if port is None:
        port = args.port_positional
    if port is None:
        port = int(os.environ.get("PORT", "8091"))

    db = args.db or args.db_positional or os.environ.get("QUEUE_DB") or os.environ.get("DB_PATH") or "queue.db"
    DB_PATH = db
    DB_INSTANCE = None
    init_db(db)

    httpd = http.server.ThreadingHTTPServer((args.host, port), Handler)
    httpd.daemon_threads = True
    httpd.allow_reuse_address = True
    print(f"queue_server listening on {args.host}:{port} db={db}", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
