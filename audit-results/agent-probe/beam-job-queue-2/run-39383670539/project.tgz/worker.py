#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.request


def env(name, *alts):
    for n in (name,) + alts:
        v = os.environ.get(n)
        if v:
            return v
    return None


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("name_positional", nargs="?", default=None)
    p.add_argument("--worker", "--name", dest="worker", default=None)
    p.add_argument("--server", "--url", "--base-url", dest="server", default=None)
    p.add_argument("--port", type=int, default=None)
    p.add_argument("--host", default=None)
    p.add_argument("--lease-seconds", type=float, default=10.0)
    p.add_argument("--poll", type=float, default=0.3)
    p.add_argument("--once", action="store_true")
    args = p.parse_args()

    worker = args.worker or args.name_positional or env("WORKER", "WORKER_NAME", "NAME") or f"worker-{os.getpid()}"
    server = args.server or env("SERVER_URL", "QUEUE_SERVER", "BASE_URL", "QUEUE_URL")
    if server is None:
        host = args.host or env("HOST", "SERVER_HOST") or "127.0.0.1"
        port = args.port
        if port is None:
            port_env = env("PORT", "SERVER_PORT")
            port = int(port_env) if port_env else 8091
        server = f"http://{host}:{port}"
    server = server.rstrip("/")
    return worker, server, args


def request(server, method, path, body=None, timeout=30):
    url = server + path
    data = None
    headers = {}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            if not raw:
                return resp.status, {}
            return resp.status, json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            obj = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:
            obj = {"error": raw.decode("utf-8", "ignore")}
        return e.code, obj


def process_job(job):
    kind = job.get("kind")
    payload = job.get("payload") or {}
    if kind == "sleep":
        seconds = float(payload.get("seconds", 0))
        time.sleep(seconds)
        return {"slept": seconds}
    if kind == "fail_n":
        n = int(payload.get("n", 0))
        attempts = int(job.get("attempts", 0))
        if attempts <= n:
            raise RuntimeError(f"intentional failure on attempt {attempts}")
        return {"ok": True, "attempts": attempts}
    if kind == "hash":
        text = payload.get("text", "")
        times = int(payload.get("times", 1))
        return hashlib.sha256((text * times).encode("utf-8")).hexdigest()
    raise ValueError(f"unknown kind: {kind}")


def main():
    worker, server, args = parse_args()
    print(f"worker {worker} -> {server}", flush=True)
    while True:
        status, resp = request(server, "POST", "/lease", {"worker": worker, "seconds": args.lease_seconds})
        job = None
        if status == 200:
            job = resp.get("job", None)
            if job is None and "id" in resp and "kind" in resp:
                job = resp
        if not job:
            time.sleep(args.poll)
            if args.once:
                # no job available; exit if once? keep trying briefly
                pass
            continue
        job_id = job["id"]
        try:
            result = process_job(job)
            s, r = request(server, "POST", f"/jobs/{job_id}/done", {"worker": worker, "result": result})
            if s not in (200, 201, 204):
                # maybe lease expired; nothing to do
                pass
        except Exception as e:
            request(server, "POST", f"/jobs/{job_id}/fail", {"worker": worker, "error": str(e)})
        if args.once:
            break


if __name__ == "__main__":
    main()
