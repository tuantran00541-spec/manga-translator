#!/usr/bin/env python3
"""A small URL shortener service built on the Python standard library only.

Endpoints
---------
POST /shorten          {"url": "https://example.com"} -> {"code": "ab12cd", "short": "http://127.0.0.1:8090/ab12cd"}
GET  /<code>           302 Found redirect to the original URL
GET  /stats/<code>     {"url": ..., "hits": N, "created": "<ISO-8601>"}

Storage lives in ``shortener.db`` next to this file (see ``DEFAULT_DB_PATH``),
so links survive a restart of the process.
"""

from __future__ import annotations

import argparse
import json
import os
import secrets
import sqlite3
import string
import sys
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_DB_PATH = BASE_DIR / "shortener.db"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8090

#: Codes are exactly 6 characters drawn from the URL-safe alphabet
#: (RFC 3986 unreserved characters, i.e. no '/' and no '+' or '=').
CODE_LENGTH = 6
CODE_ALPHABET = string.ascii_letters + string.digits + "-_"

#: The redirect status used by GET /<code>.
#:
#: 302 Found is the temporary redirect defined by RFC 9110 section 15.4.3:
#: "Since the redirection might be altered on occasion, the client ought to
#: continue to use the target URI for future requests."  The mapping
#: <code> -> URL may be changed later, so a *temporary* status is the correct
#: one; 301/308 would let clients cache the mapping as permanent.
#: See README.md for the full reasoning and sources.
DEFAULT_REDIRECT_STATUS = 302


class InvalidURLError(ValueError):
    """Raised when the supplied URL cannot be shortened."""


def now_iso() -> str:
    """Return the current UTC time as an ISO-8601 timestamp."""
    return datetime.now(timezone.utc).isoformat()


def validate_url(raw: object) -> str:
    """Validate a candidate URL and return it unchanged.

    Only absolute ``http`` and ``https`` URLs are accepted; anything else
    raises :class:`InvalidURLError` (the caller turns that into HTTP 400).
    """
    if not isinstance(raw, str):
        raise InvalidURLError("url must be a string")
    url = raw.strip()
    if not url:
        raise InvalidURLError("url must not be empty")
    try:
        parts = urlsplit(url)
    except ValueError as exc:  # pragma: no cover - urlsplit is very forgiving
        raise InvalidURLError(f"invalid url: {exc}") from exc
    if parts.scheme.lower() not in ("http", "https"):
        raise InvalidURLError("only http:// and https:// URLs can be shortened")
    if not parts.netloc:
        raise InvalidURLError("url must include a host")
    return url


class Store:
    """Tiny sqlite3-backed link store.

    One connection per thread (``threading.local``) plus WAL mode, so the
    server can handle requests concurrently and so that several processes may
    share the same database file.
    """

    SCHEMA = """
        CREATE TABLE IF NOT EXISTS links (
            code    TEXT PRIMARY KEY,
            url     TEXT NOT NULL,
            created TEXT NOT NULL,
            hits    INTEGER NOT NULL DEFAULT 0
        );
    """

    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        with self._connect_new() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executescript(self.SCHEMA)

    def _connect_new(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=10000")
        return conn

    def _conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = self._connect_new()
            self._local.conn = conn
        return conn

    # -- writes ---------------------------------------------------------
    def add(self, url: str, created: str | None = None) -> str:
        """Store ``url`` under a fresh unique code and return that code."""
        created = created or now_iso()
        conn = self._conn()
        for _ in range(50):
            code = "".join(secrets.choice(CODE_ALPHABET) for _ in range(CODE_LENGTH))
            try:
                with conn:
                    conn.execute(
                        "INSERT INTO links (code, url, created, hits) VALUES (?, ?, ?, 0)",
                        (code, url, created),
                    )
                return code
            except sqlite3.IntegrityError:
                continue  # astronomically unlikely collision, try again
        raise RuntimeError("could not allocate a unique code")

    def record_hit(self, code: str) -> bool:
        """Increment the hit counter for ``code``; True if the code exists."""
        conn = self._conn()
        with conn:
            cur = conn.execute("UPDATE links SET hits = hits + 1 WHERE code = ?", (code,))
        return cur.rowcount > 0

    # -- reads ----------------------------------------------------------
    def get(self, code: str) -> sqlite3.Row | None:
        cur = self._conn().execute(
            "SELECT code, url, created, hits FROM links WHERE code = ?", (code,)
        )
        return cur.fetchone()

    def close(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None


class ShortenerHandler(BaseHTTPRequestHandler):
    """HTTP request handler for the shortener."""

    server_version = "TinyShortener/1.0"
    protocol_version = "HTTP/1.1"

    # -- helpers --------------------------------------------------------
    @property
    def store(self) -> Store:
        return self.server.store  # type: ignore[attr-defined]

    @property
    def base_url(self) -> str:
        return self.server.base_url  # type: ignore[attr-defined]

    @property
    def redirect_status(self) -> int:
        return self.server.redirect_status  # type: ignore[attr-defined]

    def _send(self, status: int, body: bytes = b"", content_type: str | None = None,
              extra_headers: dict[str, str] | None = None) -> None:
        self.send_response(status)
        if content_type:
            self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if body and self.command != "HEAD":
            self.wfile.write(body)

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self._send(status, body, "application/json; charset=utf-8")

    def _error(self, status: int, message: str) -> None:
        self._send_json(status, {"error": message})

    def _read_body(self) -> bytes:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            return b""
        return self.rfile.read(length)

    # -- routing --------------------------------------------------------
    def do_POST(self) -> None:  # noqa: N802 - http.server API
        path = self.path.split("?", 1)[0].rstrip("/") or "/"
        if path == "/shorten":
            self._handle_shorten()
            return
        if path == "/stats" or path.startswith("/stats/"):
            self._error(405, "use GET for stats")
            return
        self._error(404, "not found")

    def do_GET(self) -> None:  # noqa: N802 - http.server API
        self._handle_get(count_hit=True)

    def do_HEAD(self) -> None:  # noqa: N802 - http.server API
        self._handle_get(count_hit=False)

    # -- endpoint implementations --------------------------------------
    def _handle_get(self, count_hit: bool) -> None:
        path = self.path.split("?", 1)[0]
        if path != "/" and path.endswith("/"):
            path = path.rstrip("/")
        if path in ("", "/"):
            self._error(404, "not found")
            return
        if path == "/shorten":
            self._send(405, b"", extra_headers={"Allow": "POST"})
            return
        if path.startswith("/stats/"):
            self._handle_stats(path[len("/stats/"):])
            return
        if path.startswith("/stats"):
            self._error(404, "not found")
            return
        if "/" in path.strip("/"):
            self._error(404, "not found")
            return
        self._handle_redirect(path.strip("/"), count_hit=count_hit)

    def _handle_redirect(self, code: str, count_hit: bool) -> None:
        row = self.store.get(code)
        if row is None:
            self._error(404, "unknown code")
            return
        if count_hit:
            self.store.record_hit(code)
        self._send(self.redirect_status, b"", extra_headers={
            "Location": row["url"],
            # The mapping may change later, so do not let clients cache it.
            "Cache-Control": "no-store",
        })

    def _handle_stats(self, code: str) -> None:
        code = code.strip("/")
        if not code:
            self._error(404, "unknown code")
            return
        row = self.store.get(code)
        if row is None:
            self._error(404, "unknown code")
            return
        self._send_json(200, {
            "url": row["url"],
            "hits": row["hits"],
            "created": row["created"],
        })

    def _handle_shorten(self) -> None:
        raw = self._read_body()
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._error(400, "request body must be a JSON object")
            return
        if not isinstance(payload, dict):
            self._error(400, "request body must be a JSON object")
            return
        if "url" not in payload:
            self._error(400, "missing 'url' field")
            return
        try:
            url = validate_url(payload["url"])
        except InvalidURLError as exc:
            self._error(400, str(exc))
            return
        code = self.store.add(url)
        self._send_json(200, {"code": code, "short": f"{self.base_url}/{code}"})

    def log_message(self, fmt: str, *args) -> None:  # pragma: no cover - noise
        print(self.address_string(), fmt % args, file=sys.stderr)


class ShortenerServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, handler_class, store, base_url, redirect_status):
        super().__init__(address, handler_class)
        self.store = store
        self.base_url = self._resolve_base_url(base_url)
        self.redirect_status = redirect_status

    def _resolve_base_url(self, base_url: str | None) -> str:
        """Work out the public base URL used to build the ``short`` field.

        ``None`` means "derive it from the address the server actually
        bound to" (handy when port 0 is used).  An explicit value may use
        the ``{host}``/``{port}`` placeholders.
        """
        host, port = self.server_address[:2]
        if not base_url:
            return f"http://{host}:{port}"
        return base_url.format(host=host, port=port).rstrip("/")


def build_server(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT,
                 db_path: str | os.PathLike[str] = DEFAULT_DB_PATH,
                 base_url: str | None = None,
                 redirect_status: int = DEFAULT_REDIRECT_STATUS) -> ShortenerServer:
    store = Store(db_path)
    return ShortenerServer((host, port), ShortenerHandler, store,
                           base_url, redirect_status)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="A tiny URL shortener service.")
    parser.add_argument("--host", default=os.environ.get("SHORTENER_HOST", DEFAULT_HOST))
    parser.add_argument("--port", type=int, default=int(os.environ.get("SHORTENER_PORT", DEFAULT_PORT)))
    parser.add_argument("--db", default=os.environ.get("SHORTENER_DB", str(DEFAULT_DB_PATH)),
                        help="sqlite database file (default: shortener.db next to this file)")
    parser.add_argument("--base-url", default=os.environ.get("SHORTENER_BASE_URL") or None,
                        help="public base URL used to build the 'short' field "
                             "(default: derived from the bound address; "
                             "'{host}' and '{port}' placeholders are supported)")
    parser.add_argument("--redirect-status", type=int,
                        default=int(os.environ.get("SHORTENER_REDIRECT_STATUS", DEFAULT_REDIRECT_STATUS)),
                        help="HTTP status used for GET /<code> (default: 302)")
    args = parser.parse_args(argv)

    server = build_server(args.host, args.port, args.db, args.base_url, args.redirect_status)
    host, port = server.server_address[:2]
    print(f"shortener listening on http://{host}:{port} "
          f"(db={args.db}, base_url={server.base_url}, redirect={args.redirect_status})",
          flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
