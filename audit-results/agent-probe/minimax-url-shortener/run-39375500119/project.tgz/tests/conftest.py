"""Shared fixtures: run the real server on an ephemeral free port."""
import http.client
import json
import sys
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import shortener  # noqa: E402


class Client:
    """Tiny HTTP client that never follows redirects (so we can inspect them)."""

    def __init__(self, port: int) -> None:
        self.port = port

    def request(self, method, path, body=None, headers=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        try:
            conn.request(method, path, body=body, headers=headers or {})
            resp = conn.getresponse()
            data = resp.read()
            return resp.status, dict(resp.getheaders()), data
        finally:
            conn.close()

    def get(self, path, headers=None):
        return self.request("GET", path, headers=headers)

    def post_json(self, path, payload):
        body = json.dumps(payload).encode("utf-8")
        return self.request("POST", path, body=body,
                            headers={"Content-Type": "application/json"})

    def post_raw(self, path, body: bytes, headers=None):
        return self.request("POST", path, body=body, headers=headers)


def start_server(db_path, port=0):
    """Start the shortener on a free port; returns (server, port)."""
    server = shortener.build_server(
        host="127.0.0.1",
        port=port,
        db_path=db_path,
        base_url=None,  # derive the public base URL from the bound address
        redirect_status=shortener.DEFAULT_REDIRECT_STATUS,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    actual_port = server.server_address[1]
    return server, actual_port


@pytest.fixture
def db_path(tmp_path):
    return tmp_path / "shortener.db"


@pytest.fixture
def running(db_path):
    server, port = start_server(db_path)
    try:
        yield port
    finally:
        server.shutdown()
        server.server_close()


@pytest.fixture
def client(running):
    return Client(running)
