"""End-to-end tests for the tiny URL shortener."""
import json
import pathlib
import re
from datetime import datetime

from conftest import Client, start_server

CODE_RE = re.compile(r"^[A-Za-z0-9_-]{6}$")


def shorten(client, url):
    status, headers, body = client.post_json("/shorten", {"url": url})
    assert status == 200, (status, body)
    return json.loads(body)


# --- POST /shorten ---------------------------------------------------------

def test_shorten_returns_code_and_short(client):
    payload = shorten(client, "https://example.com/some/page?a=1&b=2")
    assert CODE_RE.match(payload["code"]), payload
    assert payload["short"].endswith("/" + payload["code"])
    assert payload["short"].startswith("http://127.0.0.1:")


def test_short_uses_the_port_the_server_listens_on(client):
    payload = shorten(client, "https://example.com/port")
    assert payload["short"] == f"http://127.0.0.1:{client.port}/{payload['code']}"


def test_code_is_six_url_safe_characters(client):
    seen = set()
    for i in range(25):
        payload = shorten(client, f"https://example.com/{i}")
        code = payload["code"]
        assert len(code) == 6
        assert re.fullmatch(r"[A-Za-z0-9_-]+", code), code
        seen.add(code)
    assert len(seen) > 1, "codes should not all be identical"


def test_shorten_preserves_the_original_url(client):
    url = "https://example.com/path?q=hello%20world&x=1"
    payload = shorten(client, url)
    status, headers, body = client.get("/stats/" + payload["code"])
    assert status == 200
    assert json.loads(body)["url"] == url


def test_non_http_url_is_rejected_with_400(client):
    for bad in ["ftp://example.com/file", "javascript:alert(1)", "file:///etc/passwd",
                "gopher://example.com", "mailto:someone@example.com", "example.com",
                "ws://example.com", "data:text/plain;base64,QQ=="]:
        status, headers, body = client.post_json("/shorten", {"url": bad})
        assert status == 400, (bad, status, body)


def test_missing_or_malformed_body_is_rejected_with_400(client):
    status, _, _ = client.post_json("/shorten", {})
    assert status == 400
    status, _, _ = client.post_raw("/shorten", b"not json")
    assert status == 400
    status, _, _ = client.post_raw("/shorten", b"[1,2,3]")
    assert status == 400
    status, _, _ = client.post_json("/shorten", {"url": 42})
    assert status == 400
    status, _, _ = client.post_json("/shorten", {"url": ""})
    assert status == 400


# --- GET /<code> -----------------------------------------------------------

def test_redirect_points_at_the_original_url(client):
    url = "https://example.com/target"
    payload = shorten(client, url)
    status, headers, body = client.get("/" + payload["code"])
    assert status in (301, 302, 307, 308), status
    assert headers["Location"] == url


def test_redirect_uses_the_correct_status_for_a_link_that_may_change(client):
    """302 Found: RFC 9110 section 15.4.3 - temporary redirect, because the
    mapping <code> -> URL may be changed later."""
    payload = shorten(client, "https://example.com/may-change")
    status, headers, _ = client.get("/" + payload["code"])
    assert status == 302, status
    assert "Location" in headers


def test_redirect_increments_the_hit_counter(client):
    payload = shorten(client, "https://example.com/hits")
    code = payload["code"]
    for expected in (1, 2, 3):
        status, _, _ = client.get("/" + code)
        assert status == 302
        _, _, body = client.get("/stats/" + code)
        assert json.loads(body)["hits"] == expected


# --- GET /stats/<code> -----------------------------------------------------

def test_stats_reports_url_hits_and_created(client):
    url = "https://example.com/stats"
    payload = shorten(client, url)
    code = payload["code"]
    status, headers, body = client.get("/stats/" + code)
    assert status == 200
    assert "application/json" in headers["Content-Type"]
    data = json.loads(body)
    assert set(data) == {"url", "hits", "created"}
    assert data["url"] == url
    assert data["hits"] == 0
    parsed = datetime.fromisoformat(data["created"])
    assert parsed.tzinfo is not None
    assert abs((datetime.now(parsed.tzinfo) - parsed).total_seconds()) < 300


def test_stats_created_survives_a_restart(db_path):
    server, port = start_server(db_path)
    client = Client(port)
    payload = shorten(client, "https://example.com/persist")
    code = payload["code"]
    client.get("/" + code)
    server.shutdown()
    server.server_close()

    # A brand new process would open the same file; simulate that here.
    server2, port2 = start_server(db_path)
    try:
        client2 = Client(port2)
        status, _, body = client2.get("/stats/" + code)
        assert status == 200
        data = json.loads(body)
        assert data["url"] == "https://example.com/persist"
        assert data["hits"] == 1
        status, headers, _ = client2.get("/" + code)
        assert status == 302
        assert headers["Location"] == "https://example.com/persist"
    finally:
        server2.shutdown()
        server2.server_close()


# --- unknown codes are 404 everywhere --------------------------------------

def test_unknown_code_is_404_everywhere(client):
    status, _, _ = client.get("/zzzzzz")
    assert status == 404
    status, _, _ = client.get("/stats/zzzzzz")
    assert status == 404
    status, _, _ = client.get("/nope")
    assert status == 404
    status, _, _ = client.get("/stats/nope")
    assert status == 404


def test_unknown_code_after_restart_is_404(db_path):
    server, port = start_server(db_path)
    server.shutdown()
    server.server_close()
    server2, port2 = start_server(db_path)
    try:
        client2 = Client(port2)
        assert client2.get("/zzzzzz")[0] == 404
        assert client2.get("/stats/zzzzzz")[0] == 404
    finally:
        server2.shutdown()
        server2.server_close()


def test_database_file_is_created_next_to_the_code(db_path):
    server, port = start_server(db_path)
    try:
        Client(port).post_json("/shorten", {"url": "https://example.com/db"})
    finally:
        server.shutdown()
        server.server_close()
    assert db_path.exists()


# --- a genuine process restart ---------------------------------------------

def test_data_survives_a_real_process_restart(tmp_path):
    """Start shortener.py as a separate process, kill it, start it again and
    check that the link, its hit count and its creation time are still there."""
    import os
    import signal
    import socket
    import subprocess
    import sys
    import time

    project_root = pathlib.Path(__file__).resolve().parent.parent
    db = tmp_path / "restart.db"

    def free_port():
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            return s.getsockname()[1]

    def launch(port):
        proc = subprocess.Popen(
            [sys.executable, str(project_root / "shortener.py"),
             "--port", str(port), "--db", str(db)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=str(project_root),
        )
        deadline = time.time() + 15
        while time.time() < deadline:
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                    return proc
            except OSError:
                if proc.poll() is not None:
                    raise AssertionError("server exited: " + proc.stderr.read().decode())
                time.sleep(0.05)
        proc.kill()
        raise AssertionError("server did not start in time")

    port = free_port()
    proc = launch(port)
    try:
        client = Client(port)
        payload = shorten(client, "https://example.com/real-restart")
        code = payload["code"]
        client.get("/" + code)
        client.get("/" + code)
        assert json.loads(client.get("/stats/" + code)[2])["hits"] == 2
    finally:
        proc.send_signal(signal.SIGTERM)
        proc.wait(timeout=15)

    # Same database file, brand new process.
    proc2 = launch(port)
    try:
        client2 = Client(port)
        status, headers, body = client2.get("/stats/" + code)
        assert status == 200
        data = json.loads(body)
        assert data["url"] == "https://example.com/real-restart"
        assert data["hits"] == 2
        status, headers, _ = client2.get("/" + code)
        assert status == 302
        assert headers["Location"] == "https://example.com/real-restart"
    finally:
        proc2.send_signal(signal.SIGTERM)
        proc2.wait(timeout=15)
