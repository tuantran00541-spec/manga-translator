# Tiny URL Shortener

A minimal URL shortener built with the Python standard library only
(`http.server` + `sqlite3`). No third-party runtime dependencies.

* `shortener.py` - the service
* `shortener.db` - the sqlite database (created next to `shortener.py`)
* `tests/` - the pytest suite

## Running it

```bash
python3 shortener.py                 # listens on http://127.0.0.1:8090
python3 shortener.py --port 9000     # different port
python3 shortener.py --db /tmp/x.db  # different database file
```

Options (all also settable via the environment variables `SHORTENER_HOST`,
`SHORTENER_PORT`, `SHORTENER_DB`, `SHORTENER_BASE_URL` and
`SHORTENER_REDIRECT_STATUS`):

| flag | default | meaning |
| --- | --- | --- |
| `--host` | `127.0.0.1` | bind address |
| `--port` | `8090` | bind port |
| `--db` | `shortener.db` next to `shortener.py` | sqlite database file |
| `--base-url` | derived from the bound address | public base used for the `short` field; supports `{host}`/`{port}` placeholders |
| `--redirect-status` | `302` | HTTP status used by `GET /<code>` |

The database lives in `shortener.db` next to the code, so every link survives a
restart of the process (the WAL files `shortener.db-wal` and `shortener.db-shm`
belong to it as well).

## Running the tests

```bash
python3 -m pytest -q
```

The tests start the real server on a free (ephemeral) port, exercise every rule
below, and restart the server - once in-process and once as a genuinely
separate process - to prove that the data survives.

## API

### `POST /shorten`

Request body: `{"url": "https://example.com/some/page"}`

Response `200`:

```json
{"code": "aB3-xZ", "short": "http://127.0.0.1:8090/aB3-xZ"}
```

* `code` is exactly 6 characters from the URL-safe alphabet
  `A-Z a-z 0-9 - _` (the RFC 3986 unreserved characters, so no `/`, `+` or `=`).
* `short` is the absolute URL of the short link.
* A URL that is not `http://` or `https://` is rejected with `400` and a JSON
  body `{"error": "..."}`. So are a missing `url` field, a non-string `url`, an
  empty `url`, and a body that is not a JSON object.

```bash
curl -s -X POST http://127.0.0.1:8090/shorten \
     -H 'Content-Type: application/json' \
     -d '{"url": "https://example.com/hello"}'
```

### `GET /<code>`

Redirects to the original URL with `302 Found` and a `Location` header (see
the next section for why 302 and not 301/307/308).

```bash
curl -si http://127.0.0.1:8090/aB3-xZ | head -3
# HTTP/1.1 302 Found
# Location: https://example.com/hello
```

An unknown code returns `404` with a JSON body `{"error": "unknown code"}`.

Every successful redirect increments the hit counter of that code.

### `GET /stats/<code>`

Response `200`:

```json
{"url": "https://example.com/hello", "hits": 3, "created": "2025-01-31T12:04:05.123456+00:00"}
```

* `url` - the original URL
* `hits` - how many times `GET /<code>` has been served
* `created` - ISO-8601 timestamp (UTC, with offset) of when the link was stored

An unknown code returns `404`.

### Errors

| status | when |
| --- | --- |
| `400` | `POST /shorten` with a missing/invalid/non-http(s) URL or a malformed body |
| `404` | any unknown code, on both `GET /<code>` and `GET /stats/<code>` |
| `405` | wrong method for a known path (e.g. `GET /shorten`) |

## Which redirect status? - `302 Found`

**Answer: `GET /<code>` answers `302 Found`, a temporary redirect.**

### Why

A short link is a *mapping* `<code> -> URL`, and that mapping may be changed
later: the target site may move, the owner may want to point the code at a
different page, and so on. The correct status is therefore the one that says
"the target may change, keep asking".

RFC 9110, section 15.4.3 ("302 Found") says:

> The 302 (Found) status code indicates that the target resource resides
> temporarily under a different URI. Since the redirection might be altered on
> occasion, the client ought to continue to use the target URI for future
> requests.

That last sentence is exactly the semantics of a short link: the client "ought
to continue to use the target URI for future requests", i.e. it must not
conclude that the mapping is permanent.

The permanent statuses are the wrong ones:

* `301 Moved Permanently` (RFC 9110, section 15.4.2): "the target resource has
  been assigned a new permanent URI and any future references to this
  resource ought to use one of the enclosed URIs." Clients are expected to
  replace the old link with the new one (and search engines transfer the
  ranking to the new URL). Using 301 for a mapping that may still change would
  freeze a temporary decision into the clients' link books.
* `308 Permanent Redirect` (RFC 7538, section 3; RFC 9110, section 15.4.9):
  the same permanent semantics - "any future references to this resource ought
  to use one of the enclosed URIs" - so it is wrong here too. Its only
  difference from 301 is that a user agent must not change the request method
  from POST to GET, which is irrelevant for a `GET /<code>` link.

`307 Temporary Redirect` (RFC 9110, section 15.4.8) is also a temporary
redirect and would be defensible, but it exists for a different purpose:

> The 307 (Temporary Redirect) status code indicates that the target resource
> resides temporarily under a different URI and the user agent MUST NOT change
> the request method if it performs an automatic redirection to that URI.

Its distinguishing feature is preserving the request method and body across the
redirect. Our redirect is always a `GET`, so 307 would behave exactly like 302
(MDN: "307 and 302 responses are identical when the request method is GET"),
while 302 is the status every client, proxy and browser understands for "go
look there for now".

Because the mapping may change later, the redirect is additionally sent with
`Cache-Control: no-store`, so that no client or intermediary pins the current
target in a cache after it has seen the response. (RFC 9110, section 15.1,
lists 301 and 308 among the heuristically cacheable status codes, while 302
and 307 are not heuristically cacheable; the explicit `no-store` makes the
intent unambiguous regardless of the caching layer.)

### Sources

* RFC 9110, *HTTP Semantics*, IETF, June 2022 -
  <https://www.rfc-editor.org/rfc/rfc9110#section-15.4.3> (302 Found),
  <https://www.rfc-editor.org/rfc/rfc9110#section-15.4.2> (301 Moved
  Permanently), <https://www.rfc-editor.org/rfc/rfc9110#section-15.4.8>
  (307 Temporary Redirect), <https://www.rfc-editor.org/rfc/rfc9110#section-15.4.9>
  (308 Permanent Redirect) and
  <https://www.rfc-editor.org/rfc/rfc9110#section-15.1> (cacheability).
* RFC 7538, *Permanent Redirect to Irrevocable URL*, IETF, October 2015 -
  <https://www.rfc-editor.org/rfc/rfc7538#section-3>.
* MDN Web Docs, HTTP response status codes -
  <https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status/302>,
  <https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status/301>,
  <https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status/307>,
  <https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status/308>.

## Implementation notes

* `http.server.ThreadingHTTPServer` - one thread per request.
* `sqlite3` with WAL mode, one connection per thread and a `busy_timeout` for
  concurrent access. The `links` table holds `code` (primary key), `url`,
  `created` and `hits`.
* Codes are generated with `secrets.choice` over the 64-character alphabet
  (6 characters => 64^6, about 6.9e10 possible codes).
* URLs are validated with `urllib.parse.urlsplit`: only `http` and `https`
  with a non-empty host are accepted.
