# Durable Job Queue

Python standard-library-only HTTP job queue backed by SQLite.

## Running

Start the server:

```bash
python3 queue_server.py
```

Start workers:

```bash
python3 worker.py http://127.0.0.1:8091 worker-1
python3 worker.py http://127.0.0.1:8091 worker-2
```

## Backoff formula

Full jitter exponential backoff, as described by AWS in
"Exponential Backoff and Jitter" (AWS Architecture Blog):
https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/

As implemented in `queue_server.py`:

```python
delay = random.uniform(0.0, min(60.0, 1.0 * 2 ** (attempt - 1)))
```

where `attempt` is the 1-based number of the failed attempt. The AWS article gives
the full-jitter form as `sleep = random_between(0, min(cap, base * 2 ** attempt))`.
