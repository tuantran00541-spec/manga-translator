#!/usr/bin/env python3
"""Durable SQLite-backed job queue HTTP server."""

import argparse
import contextlib
import http.server
import json
import math
import os
import random
import re
import signal
import sqlite3
import threading
import time
import urllib.parse

DB_PATH_DEFAULT = "queue.db"
STATES = ("ready", "leased", "done", "failed-waiting", "dead")

# Full jitter backoff parameters (AWS "Exponential Backoff and Jitter").
BACKOFF_BASE = 1.0
BACKOFF_CAP = 60.0


def backoff_delay(attempt):
    """Full jitter: uniform(0, min(cap, base * 2 ** (attempt - 1)))."""
    high = min(BACKOFF_CAP, BACKOFF_BASE * (2 ** max(0, attempt - 1)))
    return random.uniform(0.0, high)


class Database:
    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        self.conn = sqlite3.connect(path, timeout=30.0, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA busy_timeout=30000")
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self._init_schema()

    @contextlib.contextmanager
    def tx(self):
        with self.lock:
            self.conn.execute("BEGIN IMMEDIATE")
            try:
                yield
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise

    def _init_schema(self):
        with self.tx():
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    max_attempts INTEGER NOT NULL,
                    key TEXT UNIQUE,
                    state TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    run_at REAL NOT NULL,
                    created_at REAL NOT NULL,
                    leased_by TEXT,
                    lease_expires_at REAL,
                    last_error TEXT,
                    result TEXT,
                    done_at REAL
                )
                """
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_jobs_state_run ON jobs(state, run_at)"
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_jobs_created ON jobs(created_at, id)"
            )

    def _promote(self, now):
        # Expired leases go back to ready.
        self.conn.execute(
            """
            UPDATE jobs
            SET state='ready', leased_by=NULL, lease_expires_at=NULL
            WHERE state='leased' AND lease_expires_at IS NOT NULL
              AND lease_expires_at <= ?
            """,
            (now,),
        )
        # Failed jobs whose backoff has elapsed become ready again.
        self.conn.execute(
            """
            UPDATE jobs
            SET state='ready'
            WHERE state='failed-waiting' AND run_at <= ?
            """,
            (now,),
        )

    def _row_to_dict(self, row):
        if row is None:
            return None
        result_raw = row["result"]
        try:
            result = json.loads(result_raw) if result_raw is not None else None
        except Exception:
            result = result_raw
        try:
            payload = json.loads(row["payload"])
        except Exception:
            payload = row["payload"]
        state = row["state"]
        return {
            "id": row["id"],
            "kind": row["kind"],
            "payload": payload,
            "max_attempts": row["max_attempts"],
            "key": row["key"],
            "state": state,
            "status": state,
            "attempts": row["attempts"],
            "run_at": row["run_at"],
            "created_at": row["created_at"],
            "leased_by": row["leased_by"],
            "lease_expires_at": row["lease_expires_at"],
            "last_error": row["last_error"],
            "error": row["last_error"],
            "result": result,
            "done_at": row["done_at"],
        }

    def create_job(self, kind, payload, max_attempts, key):
        now = time.time()
        payload_json = json.dumps(payload, separators=(",", ":"))
        with self.tx():
            try:
                cur = self.conn.execute(
                    """
                    INSERT INTO jobs
                    (kind, payload, max_attempts, key, state, attempts, run_at, created_at)
                    VALUES (?, ?, ?, ?, 'ready', 0, ?, ?)
                    """,
                    (kind, payload_json, int(max_attempts), key, now, now),
                )
                return cur.lastrowid
            except sqlite3.IntegrityError:
                if key is None:
                    raise
                row = self.conn.execute(
                    "SELECT id FROM jobs WHERE key=?", (key,)
                ).fetchone()
                if row is None:
                    raise
                return row["id"]

    def lease_job(self, worker, seconds):
        now = time.time()
        try:
            seconds = float(seconds)
        except (TypeError, ValueError):
            seconds = 30.0
        if seconds <= 0:
            seconds = 1.0
        with self.tx():
            self._promote(now)
            row = self.conn.execute(
                """
                SELECT id FROM jobs
                WHERE state='ready'
                ORDER BY created_at ASC, id ASC
                LIMIT 1
                """
            ).fetchone()
            if row is None:
                return None
            job_id = row["id"]
            cur = self.conn.execute(
                """
                UPDATE jobs
                SET state='leased', leased_by=?, lease_expires_at=?,
                    attempts=attempts + 1
                WHERE id=? AND state='ready'
                """,
                (worker, now + seconds, job_id),
            )
            if cur.rowcount != 1:
                return None
            row = self.conn.execute(
                "SELECT * FROM jobs WHERE id=?", (job_id,)
            ).fetchone()
            return self._row_to_dict(row)

    def complete_job(self, job_id, worker, result=None):
        now = time.time()
        with self.tx():
            self._promote(now)
            row = self.conn.execute(
                "SELECT * FROM jobs WHERE id=?", (job_id,)
            ).fetchone()
            if row is None:
                return ("not_found", "job not found")
            if row["state"] != "leased" or row["leased_by"] != worker:
                return ("conflict", "lease not held by this worker")
            if row["lease_expires_at"] is None or row["lease_expires_at"] <= now:
                # Promote may have reset it; treat as conflict.
                return ("conflict", "lease expired")
            result_json = None if result is None else json.dumps(result, separators=(",", ":"))
            self.conn.execute(
                """
                UPDATE jobs
                SET state='done', result=?, done_at=?,
                    leased_by=NULL, lease_expires_at=NULL
                WHERE id=?
                """,
                (result_json, now, job_id),
            )
            return ("ok", None)

    def fail_job(self, job_id, worker, error):
        now = time.time()
        with self.tx():
            self._promote(now)
            row = self.conn.execute(
                "SELECT * FROM jobs WHERE id=?", (job_id,)
            ).fetchone()
            if row is None:
                return ("not_found", "job not found", None, None)
            if row["state"] != "leased" or row["leased_by"] != worker:
                return ("conflict", "lease not held by this worker", None, None)
            if row["lease_expires_at"] is None or row["lease_expires_at"] <= now:
                return ("conflict", "lease expired", None, None)

            attempts = row["attempts"]
            max_attempts = row["max_attempts"]
            if attempts >= max_attempts:
                new_state = "dead"
                run_at = now
                delay = None
            else:
                delay = backoff_delay(attempts)
                new_state = "failed-waiting"
                run_at = now + delay

            self.conn.execute(
                """
                UPDATE jobs
                SET state=?, run_at=?, last_error=?, leased_by=NULL,
                    lease_expires_at=NULL
                WHERE id=?
                """,
                (new_state, run_at, str(error)[:4000], job_id),
            )
            return ("ok", None, delay, attempts)

    def get_job(self, job_id):
        now = time.time()
        with self.tx():
            self._promote(now)
            row = self.conn.execute(
                "SELECT * FROM jobs WHERE id=?", (job_id,)
            ).fetchone()
            return self._row_to_dict(row)

    def metrics(self):
        now = time.time()
        with self.tx():
            self._promote(now)
            rows = self.conn.execute(
                "SELECT state, created_at, done_at FROM jobs"
            ).fetchall()
        counts = {state: 0 for state in STATES}
        durations = []
        for row in rows:
            state = row["state"]
            if state in counts:
                counts[state] += 1
            if state == "done" and row["done_at"] is not None:
                durations.append(row["done_at"] - row["created_at"])
        durations.sort()
        p50 = percentile(durations, 50)
        p95 = percentile(durations, 95)
        result = {
            "counts": counts,
            "states": dict(counts),
            "p50_seconds": p50,
            "p95_seconds": p95,
            "p50": p50,
            "p95": p95,
            "jobs": len(rows),
            "done": counts["done"],
        }
        for state in STATES:
            result[state] = counts[state]
        return result


def percentile(values, p):
    if not values:
        return 0.0
    if len(values) == 1:
        return float(values[0])
    k = (len(values) - 1) * (p / 100.0)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return float(values[int(k)])
    return float(values[f] * (c - k) + values[c] * (k - f))


# Global database handle used by the HTTP handler.
DB = None


class QueueHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length) if length > 0 else b""
        if not raw:
            return {}
        return json.loads(raw.decode("utf-8"))

    def _send_json(self, status, obj):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_error_json(self, status, message):
        self._send_json(status, {"error": message})

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/")
        m = re.fullmatch(r"/jobs/(\d+)", path)
        if m:
            job = DB.get_job(int(m.group(1)))
            if job is None:
                self._send_error_json(404, "job not found")
            else:
                self._send_json(200, job)
            return
        if path == "/metrics":
            self._send_json(200, DB.metrics())
            return
        self._send_error_json(404, "not found")

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/")
        try:
            body = self._read_json()
        except Exception:
            self._send_error_json(400, "invalid json")
            return

        m = re.fullmatch(r"/jobs/(\d+)/done", path)
        if m:
            job_id = int(m.group(1))
            worker = body.get("worker")
            if not worker:
                self._send_error_json(400, "worker is required")
                return
            status, err = DB.complete_job(job_id, worker, body.get("result") if "result" in body else None)
            if status == "not_found":
                self._send_error_json(404, err)
            elif status == "conflict":
                self._send_error_json(409, err)
            else:
                self._send_json(200, {"ok": True, "id": job_id})
            return

        m = re.fullmatch(r"/jobs/(\d+)/fail", path)
        if m:
            job_id = int(m.group(1))
            worker = body.get("worker")
            if not worker:
                self._send_error_json(400, "worker is required")
                return
            error = body.get("error", "unknown error")
            status, err, delay, attempts = DB.fail_job(job_id, worker, error)
            if status == "not_found":
                self._send_error_json(404, err)
            elif status == "conflict":
                self._send_error_json(409, err)
            else:
                self._send_json(
                    200, {"ok": True, "id": job_id, "delay": delay, "attempts": attempts}
                )
            return

        if path == "/jobs":
            kind = body.get("kind")
            if not kind:
                self._send_error_json(400, "kind is required")
                return
            payload = body.get("payload", {})
            if payload is None:
                payload = {}
            if not isinstance(payload, dict):
                self._send_error_json(400, "payload must be an object")
                return
            max_attempts = body.get("max_attempts", 5)
            try:
                max_attempts = int(max_attempts)
            except (TypeError, ValueError):
                self._send_error_json(400, "max_attempts must be an integer")
                return
            if max_attempts < 1:
                max_attempts = 1
            key = body.get("key", None)
            if key is not None and not isinstance(key, str):
                key = str(key)
            try:
                job_id = DB.create_job(kind, payload, max_attempts, key)
            except Exception as exc:
                self._send_error_json(500, str(exc))
                return
            self._send_json(200, {"id": job_id})
            return

        if path == "/lease":
            worker = body.get("worker")
            if not worker:
                self._send_error_json(400, "worker is required")
                return
            seconds = body.get("seconds", 30)
            job = DB.lease_job(worker, seconds)
            if job is None:
                self._send_json(200, {"id": None, "job": None})
            else:
                response = dict(job)
                response["job"] = job
                self._send_json(200, response)
            return

        self._send_error_json(404, "not found")

    def log_message(self, fmt, *args):
        # Keep server output quiet.
        return


def parse_args():
    parser = argparse.ArgumentParser(description="Durable job queue server")
    parser.add_argument("port_positional", nargs="?")
    parser.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--db", default=None)
    return parser.parse_args()


def main():
    global DB
    args = parse_args()
    host = args.host
    port = args.port
    if port is None:
        if args.port_positional is not None:
            try:
                port = int(args.port_positional)
            except ValueError:
                # Treat as db path? Fall back to env/default.
                port = None
        if port is None:
            port = int(os.environ.get("PORT", os.environ.get("QUEUE_PORT", "8091")))
    db_path = args.db
    if db_path is None:
        # Allow positional to be a db path if it looks like one.
        if args.port_positional is not None and not args.port_positional.isdigit():
            db_path = args.port_positional
        else:
            db_path = os.environ.get(
                "QUEUE_DB",
                os.environ.get("DB_PATH", os.environ.get("DATABASE_PATH", DB_PATH_DEFAULT)),
            )
    DB = Database(db_path)

    httpd = http.server.ThreadingHTTPServer((host, port), QueueHandler)
    httpd.daemon_threads = True
    httpd.allow_reuse_address = True

    def handle_signal(signum, frame):
        raise KeyboardInterrupt()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    print(
        f"queue-server listening on http://{host}:{port} db={db_path}",
        flush=True,
    )
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
