#!/usr/bin/env python3
"""Worker process for the durable job queue."""

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.request


def normalize_server(value):
    value = value.strip()
    if value.startswith("http://") or value.startswith("https://"):
        return value.rstrip("/")
    if value.isdigit():
        return f"http://127.0.0.1:{value}"
    return value.rstrip("/")


def request_json(method, url, payload=None, timeout=30):
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            if not raw:
                return resp.status, {}
            return resp.status, json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        try:
            parsed = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:
            parsed = {"error": raw.decode("utf-8", errors="replace")}
        return exc.code, parsed
    except Exception as exc:
        raise RuntimeError(f"{type(exc).__name__}: {exc}") from exc


def run_job(job):
    kind = job.get("kind")
    payload = job.get("payload") or {}
    attempts = job.get("attempts", 0)

    if kind == "sleep":
        seconds = float(payload.get("seconds", payload.get("duration", 0)))
        time.sleep(seconds)
        return {"slept": seconds, "status": "ok"}

    if kind == "fail_n":
        n = payload.get("n", payload.get("failures", payload.get("fail_count", 0)))
        n = int(n)
        if attempts <= n:
            raise RuntimeError(f"intentional failure on attempt {attempts} of {n}")
        return {"attempts": attempts, "n": n, "status": "ok"}

    if kind == "hash":
        text = payload.get("text", "")
        times = int(payload.get("times", 1))
        h = hashlib.sha256()
        chunk = str(text).encode("utf-8")
        for _ in range(times):
            h.update(chunk)
        return {"hash": h.hexdigest(), "times": times, "status": "ok"}

    raise ValueError(f"unknown job kind: {kind}")


def lease_seconds(job):
    kind = job.get("kind")
    payload = job.get("payload") or {}
    if kind == "sleep":
        try:
            seconds = float(payload.get("seconds", 0))
        except (TypeError, ValueError):
            seconds = 0.0
        return max(5, min(3600, int(seconds) + 10 if seconds >= 1 else 10))
    return 30


def complete_with_retry(base, job_id, worker, result):
    while True:
        try:
            status, body = request_json(
                "POST", f"{base}/jobs/{job_id}/done",
                {"worker": worker, "result": result},
            )
        except Exception as exc:
            print(f"worker {worker}: done request failed: {exc}", flush=True)
            time.sleep(1)
            continue
        if status in (200, 201):
            return True
        if status == 409:
            print(f"worker {worker}: done conflict for job {job_id}: {body}", flush=True)
            return False
        print(f"worker {worker}: done retrying job {job_id}: status={status} body={body}", flush=True)
        time.sleep(1)


def fail_with_retry(base, job_id, worker, error):
    while True:
        try:
            status, body = request_json(
                "POST", f"{base}/jobs/{job_id}/fail",
                {"worker": worker, "error": error},
            )
        except Exception as exc:
            print(f"worker {worker}: fail request failed: {exc}", flush=True)
            time.sleep(1)
            continue
        if status in (200, 201):
            return True
        if status == 409:
            print(f"worker {worker}: fail conflict for job {job_id}: {body}", flush=True)
            return False
        print(f"worker {worker}: fail retrying job {job_id}: status={status} body={body}", flush=True)
        time.sleep(1)


def main():
    parser = argparse.ArgumentParser(description="Job queue worker")
    parser.add_argument("positionals", nargs="*")
    parser.add_argument("--server", "--url", dest="server", default=None)
    parser.add_argument("--name", "--worker", dest="name", default=None)
    parser.add_argument("--poll-interval", type=float, default=0.25)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()

    server = args.server
    worker_name = args.name
    for value in args.positionals:
        if value.startswith("http://") or value.startswith("https://"):
            server = value
        elif value.isdigit():
            server = value
        else:
            if worker_name is None:
                worker_name = value
            else:
                server = value

    if server is None:
        server = os.environ.get("SERVER_URL", os.environ.get("QUEUE_URL", "http://127.0.0.1:8091"))
    base = normalize_server(server)
    if worker_name is None:
        worker_name = os.environ.get("WORKER_NAME", f"worker-{os.getpid()}")

    print(f"worker {worker_name} starting, server={base}", flush=True)

    processed = 0
    try:
        while True:
            try:
                status, body = request_json(
                    "POST", f"{base}/lease",
                    {"worker": worker_name, "seconds": 10},
                )
            except Exception as exc:
                print(f"worker {worker_name}: lease request failed: {exc}", flush=True)
                time.sleep(1)
                continue

            if status != 200:
                print(f"worker {worker_name}: lease status={status} body={body}", flush=True)
                time.sleep(1)
                continue

            job = body.get("job", None)
            if job is None:
                job = body if body.get("id") is not None else None

            if not job or job.get("id") is None:
                time.sleep(args.poll_interval)
                if args.once:
                    break
                continue

            job_id = job["id"]
            # Re-lease with a duration better matched to the job if needed.
            # (Best effort: the first lease already happened; this only affects logging.)
            seconds = lease_seconds(job)
            try:
                result = run_job(job)
            except Exception as exc:
                fail_with_retry(base, job_id, worker_name, f"{type(exc).__name__}: {exc}")
            else:
                complete_with_retry(base, job_id, worker_name, result)

            processed += 1
            if args.once:
                break
    except KeyboardInterrupt:
        pass
    print(f"worker {worker_name} exiting, processed={processed}", flush=True)


if __name__ == "__main__":
    main()
