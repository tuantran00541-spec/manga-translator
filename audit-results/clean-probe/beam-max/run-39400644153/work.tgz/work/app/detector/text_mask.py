"""Build a precise binary mask of lettering using text_segmenter.onnx."""

import numpy as np
import cv2
import onnxruntime as ort
from pathlib import Path

from app.config import TEXT_SEGMENTER_MODEL, TEXT_CONF_THRESHOLD


class TextMaskDetector:
    def __init__(self, model_path=TEXT_SEGMENTER_MODEL, conf_threshold=0.05):
        self.model_path = Path(model_path)
        self.conf_threshold = conf_threshold
        self.session = ort.InferenceSession(str(self.model_path), providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name
        self.input_size = 1024

    def _preprocess(self, image):
        h, w = image.shape[:2]
        scale = self.input_size / max(h, w)
        nh, nw = int(h * scale), int(w * scale)
        resized = cv2.resize(image, (nw, nh))
        canvas = np.full((self.input_size, self.input_size, 3), 114, dtype=np.uint8)
        padx = (self.input_size - nw) // 2
        pady = (self.input_size - nh) // 2
        canvas[pady:pady + nh, padx:padx + nw] = resized
        blob = canvas.astype(np.float32) / 255.0
        blob = blob.transpose(2, 0, 1)[None]
        return blob, scale, (padx, pady), (nw, nh)

    def detect_mask(self, image: np.ndarray) -> np.ndarray:
        h, w = image.shape[:2]
        blob, scale, (padx, pady), (nw, nh) = self._preprocess(image)

        outputs = self.session.run(None, {self.input_name: blob})
        pred = outputs[0][0].T  # [N, 37]
        proto = outputs[1][0]    # [32, 256, 256]

        confs = pred[:, 4]
        keep = confs > self.conf_threshold
        if not keep.any():
            return np.zeros((h, w), dtype=np.uint8)

        boxes = pred[keep, :4]
        coeffs = pred[keep, 5:]
        confs_k = confs[keep]

        letter_mask = np.zeros((self.input_size, self.input_size), dtype=np.uint8)
        proto_flat = proto.reshape(32, -1)

        for idx in range(len(boxes)):
            cx, cy, bw, bh = boxes[idx]
            x1 = int(cx - bw / 2)
            y1 = int(cy - bh / 2)
            x2 = int(cx + bw / 2)
            y2 = int(cy + bh / 2)
            if x2 <= x1 or y2 <= y1:
                continue

            m = 1.0 / (1.0 + np.exp(-(coeffs[idx] @ proto_flat)))
            m = m.reshape(256, 256)

            px1 = max(0, x1 // 4)
            py1 = max(0, y1 // 4)
            px2 = min(256, x2 // 4 + 1)
            py2 = min(256, y2 // 4 + 1)
            if px2 <= px1 or py2 <= py1:
                continue

            sub = (m[py1:py2, px1:px2] > 0.5).astype(np.uint8)
            bw_i = max(1, x2 - x1)
            bh_i = max(1, y2 - y1)
            sub_r = cv2.resize(sub, (bw_i, bh_i), interpolation=cv2.INTER_NEAREST)

            x1c = max(0, x1)
            y1c = max(0, y1)
            x2c = min(self.input_size, x2)
            y2c = min(self.input_size, y2)
            if x2c <= x1c or y2c <= y1c:
                continue

            rx1 = x1c - x1
            ry1 = y1c - y1
            rx2 = rx1 + (x2c - x1c)
            ry2 = ry1 + (y2c - y1c)
            region = sub_r[ry1:ry2, rx1:rx2]
            letter_mask[y1c:y2c, x1c:x2c] = np.maximum(
                letter_mask[y1c:y2c, x1c:x2c], region
            )

        # Map letterbox mask back to original image coordinates
        cropped = letter_mask[pady:pady + nh, padx:padx + nw]
        orig_mask = cv2.resize(cropped, (w, h), interpolation=cv2.INTER_NEAREST)
        orig_mask = (orig_mask > 0).astype(np.uint8) * 255
        return orig_mask
