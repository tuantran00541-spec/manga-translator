"""Build a lettering mask for a page.

Strategy
--------
1.  Run the segmentation network to find *where* lettering is (soft masks).
2.  Snap those soft masks to crisp regions.
3.  Inside each region, recover the individual strokes with a local
    background-subtraction pass so we erase glyphs, not the balloon around
    them.
4.  Union everything into a single binary "erase" mask.

The bubble network is used as a second opinion: it knows about speech
balloons and free text, and its boxes help us cover lettering the
segmentation network may have missed (small SFX, captions).
"""
import numpy as np
import cv2

from app.detector.onnx_yolo import (
    INPUT_SIZE, letterbox, tile_grid, nms,
)


class BubbleDetector:
    """Ultralytics detection model with classes {0: text_bubble, 1: text_free}."""

    def __init__(self, model_path, conf: float = 0.25, threads: int = 4):
        from app.detector.onnx_yolo import make_session
        self.session = make_session(model_path, threads)
        self.input_name = self.session.get_inputs()[0].name
        self.conf = conf

    def detect(self, image: np.ndarray):
        """Return list of (cls, score, (x1,y1,x2,y2)) in image coordinates."""
        h, w = image.shape[:2]
        out = []
        for ty, tx in tile_grid(h, w):
            tile = image[ty:ty + INPUT_SIZE, tx:tx + INPUT_SIZE]
            if tile.shape[0] < 32 or tile.shape[1] < 32:
                continue
            blob, scale, px, py = letterbox(tile)
            o = self.session.run(None, {self.input_name: blob})[0][0]
            for row, cid in ((4, 0), (5, 1)):
                scores = o[row]
                keep = np.where(scores > self.conf)[0]
                for i in keep:
                    cx, cy, bw, bh = o[:4, i]
                    x1 = (cx - bw / 2 - px) / scale + tx
                    y1 = (cy - bh / 2 - py) / scale + ty
                    x2 = (cx + bw / 2 - px) / scale + tx
                    y2 = (cy + bh / 2 - py) / scale + ty
                    out.append((cid, float(scores[i]), (x1, y1, x2, y2)))
        return self._merge(out, w, h)

    @staticmethod
    def _merge(dets, w, h):
        if not dets:
            return []
        clipped = []
        for cid, sc, (x1, y1, x2, y2) in dets:
            x1 = max(0, min(w, x1)); y1 = max(0, min(h, y1))
            x2 = max(0, min(w, x2)); y2 = max(0, min(h, y2))
            if x2 - x1 < 3 or y2 - y1 < 3:
                continue
            clipped.append((cid, sc, (x1, y1, x2, y2)))
        out = []
        for cid in (0, 1):
            sel = [c for c in clipped if c[0] == cid]
            if not sel:
                continue
            boxes = np.array([c[2] for c in sel], np.float32)
            scores = np.array([c[1] for c in sel], np.float32)
            for i in nms(boxes, scores, 0.5):
                out.append(sel[i])
        return out


def soft_region_mask(dets, shape, thr=0.35):
    """Union of segmentation masks above `thr`."""
    h, w = shape
    full = np.zeros((h, w), np.float32)
    for d in dets:
        x1, y1, x2, y2 = d.x1, d.y1, d.x2, d.y2
        if x2 <= x1 or y2 <= y1:
            continue
        full[y1:y2, x1:x2] = np.maximum(full[y1:y2, x1:x2], d.mask)
    return full


def region_boxes_from_mask(mask, min_area=64):
    """Connected components of a binary mask -> list of xyxy boxes."""
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = stats[i]
        if a < min_area:
            continue
        out.append((int(x), int(y), int(x + w), int(y + h), int(a)))
    return out
