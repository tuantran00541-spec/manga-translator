"""Shared ONNX YOLO inference helpers: letterbox, tiling, decode.

Both bundled detectors are Ultralytics exports with a fixed 1024x1024 float32 input.
They expect RAW 0-255 pixel values (not 0-1).  Feeding 0-1 makes every class
score collapse to ~0, which is what the first version did.
"""
import numpy as np
import cv2
import onnxruntime as ort

INPUT_SIZE = 1024
PROTO_SIZE = 256
PAD_VALUE = 114


def make_session(model_path, threads: int = 4) -> ort.InferenceSession:
    opts = ort.SessionOptions()
    opts.intra_op_num_threads = max(1, threads)
    opts.inter_op_num_threads = 1
    opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    return ort.InferenceSession(str(model_path), opts, providers=["CPUExecutionProvider"])


def letterbox(image: np.ndarray, size: int = INPUT_SIZE, pad: int = PAD_VALUE):
    """Resize keeping aspect and centre-pad.  Returns (blob, scale, pad_x, pad_y)."""
    h, w = image.shape[:2]
    scale = size / max(h, w)
    nh, nw = max(1, int(round(h * scale))), max(1, int(round(w * scale)))
    resized = cv2.resize(image, (nw, nh), interpolation=cv2.INTER_LINEAR)
    canvas = np.full((size, size, 3), pad, dtype=np.uint8)
    px, py = (size - nw) // 2, (size - nh) // 2
    canvas[py:py + nh, px:px + nw] = resized
    blob = canvas.astype(np.float32).transpose(2, 0, 1)[None]
    return blob, scale, px, py


def tile_grid(h: int, w: int, size: int = INPUT_SIZE, overlap: int = 256):
    """Sliding window positions so every pixel is covered with generous overlap."""
    def axis(total):
        if total <= size:
            return [0]
        step = size - overlap
        pos = list(range(0, total - size + 1, step))
        if pos[-1] + size < total:
            pos.append(total - size)
        return pos

    ys = axis(h)
    xs = axis(w)
    return [(y, x) for y in ys for x in xs]


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30, 30)))


def nms(boxes: np.ndarray, scores: np.ndarray, iou_thr: float = 0.55) -> list:
    """Plain IoU NMS on xyxy boxes."""
    if len(boxes) == 0:
        return []
    x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    areas = np.maximum(0, x2 - x1) * np.maximum(0, y2 - y1)
    order = scores.argsort()[::-1]
    keep = []
    while order.size:
        i = order[0]
        keep.append(int(i))
        if order.size == 1:
            break
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        inter = np.maximum(0, xx2 - xx1) * np.maximum(0, yy2 - yy1)
        union = areas[i] + areas[order[1:]] - inter
        iou = inter / np.maximum(union, 1e-6)
        order = order[1:][iou <= iou_thr]
    return keep


def box_iou(a, b) -> float:
    ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
    ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    if inter <= 0:
        return 0.0
    area_a = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])
    area_b = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
    return inter / (area_a + area_b - inter + 1e-6)
