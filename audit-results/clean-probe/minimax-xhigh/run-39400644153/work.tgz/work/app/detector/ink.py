"""Recovering the exact letter strokes inside a detected lettering region.

The segmentation network tells us *where* lettering is, but its masks are
loose - they often cover the glyph plus a lot of background, and sometimes
a whole speech balloon.  Erasing that whole area would destroy the artwork,
so we re-derive the strokes from the pixels.

How it works
------------
1.  *Region.*  The network mask bounds the search, so neighbouring art
    cannot influence the result.

2.  *Split.*  Inside the region the intensity histogram is strongly
    bimodal: the ground (page tone, balloon fill) and the ink.  Otsu's
    method finds the split.

3.  *Which side is the ink?*  Comic lettering comes in both polarities
    (dark ink on a light ground, light ink on a dark ground) so we have to
    decide.  The ground normally dominates the region, so the ink is the
    *minority* side of the split.  We sanity check the choice: a region
    whose "ink" covers nearly all of it is a flat panel, not lettering, and
    is rejected.

4.  *Keep the soft edges.*  The strokes are cut with the Otsu threshold
    rather than a hard contrast test, so the anti-aliased fringe of every
    glyph is included.  Leaving that fringe behind is exactly what produces
    "faint ghosts of letters", so the mask is grown over it afterwards.

5.  *Cleanup.*  A letter is a compact blob, so balloon interiors and other
    big smooth regions are dropped, while word-sized groups of touching
    letters are kept.
"""
import numpy as np
import cv2

# a blob bigger than this (pixels) is a background region, not lettering
MAX_BLOB_AREA = 5200
# a blob whose bbox side exceeds this is background too
MAX_BLOB_SIDE = 300
# fallback tolerance when the histogram cannot be split
INK_TOL = 26
# the network mask value above which a pixel counts as "inside the text"
REGION_LEVEL = 0.35
# if the "ink" covers more than this much of the region it is not lettering
MAX_INK_FRACTION = 0.62


def _otsu(vals):
    """Otsu threshold, or None when the histogram cannot be split."""
    if vals.size < 8:
        return None
    lo, hi = float(vals.min()), float(vals.max())
    if hi - lo < 8:
        return None
    t, _ = cv2.threshold(vals.reshape(-1, 1), 0, 255,
                         cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return float(t)


def stroke_response(gray, region, mask=None):
    """Binary mask of candidate letter strokes inside `region`."""
    if region.sum() < 8:
        return np.zeros(gray.shape, np.uint8)

    vals = gray[region]
    t = _otsu(vals)
    cand = np.zeros(gray.shape, bool)
    if t is None:
        bg = float(np.median(vals))
        cand[region] = np.abs(gray[region].astype(np.int16) - bg) > INK_TOL
    else:
        low = gray[region] < t
        # the ground dominates the region, so the ink is the minority side
        use_low = float(low.mean()) <= 0.5
        frac = float(low.mean()) if use_low else 1.0 - float(low.mean())
        if frac > MAX_INK_FRACTION:
            # the whole region would be erased: this is a flat panel
            return np.zeros(gray.shape, np.uint8)
        cand[region] = low if use_low else ~low
    if not cand.any():
        return np.zeros(gray.shape, np.uint8)
    return cand.astype(np.uint8) * 255


def drop_background_blobs(strokes, region):
    """Remove big smooth regions (balloon interiors) but keep letter groups."""
    if not strokes.any():
        return strokes
    m = (strokes > 0).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m, 8)
    out = np.zeros_like(m)
    region_area = max(1, int(region.sum()))
    for i in range(1, n):
        x, y, w, h, a = stats[i]
        if a < 4:
            continue
        if a > MAX_BLOB_AREA or max(w, h) > MAX_BLOB_SIDE:
            continue
        # a blob that fills its bounding box and is large is a flat panel
        if a > 0.75 * w * h and a > 0.25 * region_area:
            continue
        out[lab == i] = 1
    return out


def keep_letter_like(strokes, region, min_area=4):
    """Drop specks and components that swallow the whole region."""
    if not strokes.any():
        return strokes
    m = (strokes > 0).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m, 8)
    out = np.zeros_like(m)
    region_area = max(1, int(region.sum()))
    for i in range(1, n):
        x, y, w, h, a = stats[i]
        if a < min_area:
            continue
        if a > 0.45 * region_area:
            continue
        out[lab == i] = 1
    return out


def dilate(mask, radius=1):
    """Grow the mask slightly so anti-aliased edges of strokes go too."""
    if radius <= 0:
        return mask
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * radius + 1, 2 * radius + 1))
    return cv2.dilate(mask, k)


def expand_antialias(mask, gray, radius=2, tol=70):
    """Grow a stroke mask over the anti-aliased fringe of the glyphs.

    Rendering text leaves a halo of partially-inked pixels around every
    stroke.  Erasing only the hard core leaves a faint ghost of the letter,
    so we extend the mask over neighbours that are close to the ink level.
    """
    if not mask.any():
        return mask
    core = mask > 0
    vals = gray[core]
    if vals.size == 0:
        return mask
    level = float(np.median(vals))
    grown = cv2.dilate(mask, cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (2 * radius + 1, 2 * radius + 1)))
    near = np.abs(gray.astype(np.int16) - level) < tol
    extra = grown & (~core) & near
    return np.where(extra, 255, mask).astype(np.uint8)
