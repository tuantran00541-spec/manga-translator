"""YOLOv8-seg comic text detector (text_segmenter.onnx).

Output layout: [4 bbox | 1 class score | 32 mask coefficients] x 21504 anchors
plus a [32,256,256] prototype bank.  The mask for an anchor is
    sigmoid(coeffs @ protos.reshape(32,-1)).reshape(-1,256,256)
and lives on a 256x256 grid, i.e. 1/4 of the 1024 letterboxed canvas.

We keep the per-pixel soft mask because it lets us erase exactly the glyph
pixels instead of whole balloons / bounding rectangles.
"""
import numpy as np
import cv2

from app.detector.onnx_yolo import (
    INPUT_SIZE, PROTO_SIZE, letterbox, tile_grid, sigmoid, nms,
)


class TextSeg:
    """One detected text instance."""

    __slots__ = ("x1", "y1", "x2", "y2", "score", "mask")

    def __init__(self, x1, y1, x2, y2, score, mask):
        self.x1, self.y1, self.x2, self.y2 = int(x1), int(y1), int(x2), int(y2)
        self.score = float(score)
        self.mask = mask  # float32 in [0,1], shape (h, w) matching the box

    @property
    def width(self):
        return self.x2 - self.x1

    @property
    def height(self):
        return self.y2 - self.y1

    @property
    def area(self):
        return max(0, self.width) * max(0, self.height)

    def box(self):
        return (self.x1, self.y1, self.x2, self.y2)


class TextSegmenter:
    def __init__(self, model_path, conf: float = 0.20, threads: int = 4):
        from app.detector.onnx_yolo import make_session
        self.session = make_session(model_path, threads)
        self.input_name = self.session.get_inputs()[0].name
        self.conf = conf

    def detect(self, image: np.ndarray, conf: float = None) -> list:
        """Return a list of TextSeg for the whole image."""
        thr = self.conf if conf is None else conf
        h, w = image.shape[:2]
        out = []
        for ty, tx in tile_grid(h, w):
            tile = image[ty:ty + INPUT_SIZE, tx:tx + INPUT_SIZE]
            if tile.shape[0] < 16 or tile.shape[1] < 16:
                continue
            out.extend(self._detect_tile(tile, tx, ty, thr))
        return self._merge(out, w, h)

    def _detect_tile(self, tile, tx, ty, thr):
        blob, scale, px, py = letterbox(tile)
        outputs = self.session.run(None, {self.input_name: blob})
        o0 = outputs[0][0]           # (37, N)
        protos = outputs[1][0]       # (32,256,256)
        scores = o0[4]
        keep = np.where(scores > thr)[0]
        if len(keep) == 0:
            return []
        boxes = o0[:4].T[keep]
        coeffs = o0[5:37].T[keep]
        masks = sigmoid(coeffs @ protos.reshape(32, -1)).reshape(-1, PROTO_SIZE, PROTO_SIZE)

        results = []
        for i in range(len(keep)):
            cx, cy, bw, bh = boxes[i]
            kx1, ky1 = cx - bw / 2, cy - bh / 2
            kx2, ky2 = cx + bw / 2, cy + bh / 2
            # image-space integer box
            ox1 = (kx1 - px) / scale + tx
            oy1 = (ky1 - py) / scale + ty
            ox2 = (kx2 - px) / scale + tx
            oy2 = (ky2 - py) / scale + ty
            X1, Y1 = int(np.floor(ox1)), int(np.floor(oy1))
            X2, Y2 = int(np.ceil(ox2)), int(np.ceil(oy2))
            if X2 <= X1 or Y2 <= Y1:
                continue
            # proto grid window that maps onto the image-space box
            p1 = int(np.floor(((X1 - tx) * scale + px) * PROTO_SIZE / INPUT_SIZE))
            p2 = int(np.ceil(((X2 - tx) * scale + px) * PROTO_SIZE / INPUT_SIZE))
            q1 = int(np.floor(((Y1 - ty) * scale + py) * PROTO_SIZE / INPUT_SIZE))
            q2 = int(np.ceil(((Y2 - ty) * scale + py) * PROTO_SIZE / INPUT_SIZE))
            p1 = max(0, min(PROTO_SIZE - 1, p1)); p2 = max(p1 + 1, min(PROTO_SIZE, p2))
            q1 = max(0, min(PROTO_SIZE - 1, q1)); q2 = max(q1 + 1, min(PROTO_SIZE, q2))
            sub = masks[i][q1:q2, p1:p2]
            if sub.size == 0:
                continue
            results.append((X1, Y1, X2, Y2, float(scores[keep][i]), sub))
        return results

    def _merge(self, dets, img_w, img_h):
        """NMS across tiles; clip boxes to the image and build the full-size mask."""
        if not dets:
            return []
        clipped = []
        for d in dets:
            X1 = max(0, min(img_w, d[0]))
            Y1 = max(0, min(img_h, d[1]))
            X2 = max(0, min(img_w, d[2]))
            Y2 = max(0, min(img_h, d[3]))
            if X2 - X1 < 2 or Y2 - Y1 < 2:
                continue
            clipped.append((X1, Y1, X2, Y2, d[4], d[5]))
        if not clipped:
            return []
        boxes = np.array([[c[0], c[1], c[2], c[3]] for c in clipped], np.float32)
        scores = np.array([c[4] for c in clipped], np.float32)
        keep = nms(boxes, scores, 0.6)
        out = []
        for i in keep:
            X1, Y1, X2, Y2, sc, sub = clipped[i]
            m = cv2.resize(sub.astype(np.float32), (X2 - X1, Y2 - Y1),
                           interpolation=cv2.INTER_LINEAR)
            out.append(TextSeg(X1, Y1, X2, Y2, sc, m))
        return out
