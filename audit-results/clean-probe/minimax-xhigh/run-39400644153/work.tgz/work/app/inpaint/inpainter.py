"""Erase lettering and rebuild what was underneath.

The erase mask is a set of thin letter strokes grouped into text blocks.
We rebuild in two steps:

*Flat fill* - when a text block sits on a uniform ground (the inside of a
speech balloon, a white page margin, a flat sky) we paint the sampled
background colour back in.  This is exact, artefact-free and free.

*LaMa* - when the block sits on textured art, or straddles a strong edge,
we run the bundled LaMa network to hallucinate a plausible continuation of
the artwork.

LaMa is fixed at 512x512 and costs ~3.4s per crop, so we process whole
512x512 tiles of the page in a single pass, with every stroke that falls
inside the tile merged into one mask.  Working at native resolution matters:
resizing a small crop up to 512 blurs the thin strokes and leaves ghosts.
"""
import numpy as np
import cv2
from concurrent.futures import ThreadPoolExecutor

LAMA_SIZE = 512
CONTEXT_PAD = 36
MAX_GROUP_SPAN = 470
# a ring sample is "flat" when this much of it sits at the same level
FLAT_AGREE = 0.72
FLAT_TOL = 24
# a flat ground also has low spread; this only rejects truly mixed samples
FLAT_STD = 34.0


class LamaInpainter:
    def __init__(self, model_path, threads: int = 4):
        from app.detector.onnx_yolo import make_session
        self.session = make_session(model_path, 1)
        self.workers = max(1, threads)
        self.image_input = self.session.get_inputs()[0].name
        self.mask_input = self.session.get_inputs()[1].name

    # ------------------------------------------------------------------ API
    def inpaint(self, image: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """Erase everything marked in `mask` (uint8 0/255) and rebuild."""
        mask = (mask > 127).astype(np.uint8)
        if not mask.any():
            return image.copy()

        out = image.copy()
        filled, out = self._flat_fill_pass(out, mask)
        rest = ((mask > 0) & (filled == 0)).astype(np.uint8)
        if rest.any():
            out = self._lama_pass(out, rest)
        return out

    def inpaint_blocks(self, image: np.ndarray, blocks) -> np.ndarray:
        """Rebuild a set of TextBlock objects (each has .strokes and a box)."""
        out = image.copy()
        lama_blocks = []
        for b in blocks:
            strokes = b.strokes
            if not strokes.any():
                continue
            crop = out[b.y1:b.y2, b.x1:b.x2]
            filled, newcrop = self._flat_fill_block(crop, strokes)
            out[b.y1:b.y2, b.x1:b.x2] = newcrop
            rest = (strokes > 0) & (filled == 0)
            if rest.any():
                lama_blocks.append((b, rest))
        if lama_blocks:
            self._lama_blocks(out, lama_blocks)
        return out

    # -------------------------------------------------------------- flat fill
    def _flat_fill_block(self, crop, strokes):
        """Fill the strokes of one block when the ground is uniform.

        Returns (filled_mask, new_crop).
        """
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        m = (strokes > 0)
        if not m.any():
            return np.zeros(crop.shape[:2], np.uint8), crop
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))
        n, lab, stats, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8), 8)
        filled = np.zeros(crop.shape[:2], np.uint8)
        newcrop = crop.copy()
        for i in range(1, n):
            x, y, cw, ch, area = stats[i]
            if area < 3:
                continue
            pad = 8
            rx1 = max(0, x - pad); ry1 = max(0, y - pad)
            rx2 = min(crop.shape[1], x + cw + pad)
            ry2 = min(crop.shape[0], y + ch + pad)
            sub_lab = lab[ry1:ry2, rx1:rx2]
            hole = (sub_lab == i)
            ring = (~hole) & (cv2.dilate(hole.astype(np.uint8), kernel) > 0)
            if ring.sum() < 16:
                continue
            gvals = gray[ry1:ry2, rx1:rx2][ring]
            med = float(np.median(gvals))
            if float(np.mean(np.abs(gvals - med) <= FLAT_TOL)) < FLAT_AGREE:
                continue
            if gvals.std() > FLAT_STD:
                continue
            pixels = crop[ry1:ry2, rx1:rx2][ring]
            fill = np.median(pixels, axis=0)
            region = newcrop[ry1:ry2, rx1:rx2]
            region[hole] = fill.astype(np.uint8)
            newcrop[ry1:ry2, rx1:rx2] = region
            filled[ry1:ry2, rx1:rx2][hole] = 1
        return filled, newcrop

    def _flat_fill_pass(self, image, mask):
        h, w = mask.shape
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        filled = np.zeros((h, w), np.uint8)
        n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))
        for i in range(1, n):
            x, y, cw, ch, area = stats[i]
            if area < 3:
                continue
            pad = 8
            rx1 = max(0, x - pad); ry1 = max(0, y - pad)
            rx2 = min(w, x + cw + pad); ry2 = min(h, y + ch + pad)
            sub_lab = lab[ry1:ry2, rx1:rx2]
            hole = (sub_lab == i)
            ring = (~hole) & (cv2.dilate(hole.astype(np.uint8), kernel) > 0)
            if ring.sum() < 16:
                continue
            gvals = gray[ry1:ry2, rx1:rx2][ring]
            med = float(np.median(gvals))
            if float(np.mean(np.abs(gvals - med) <= FLAT_TOL)) < FLAT_AGREE:
                continue
            if gvals.std() > FLAT_STD:
                continue
            pixels = image[ry1:ry2, rx1:rx2][ring]
            fill = np.median(pixels, axis=0)
            region = image[ry1:ry2, rx1:rx2]
            region[hole] = fill.astype(np.uint8)
            image[ry1:ry2, rx1:rx2] = region
            filled[ry1:ry2, rx1:rx2][hole] = 1
        return filled, image

    # ---------------------------------------------------------------- LaMa
    def _lama_blocks(self, image, lama_blocks):
        """Run LaMa over the blocks that could not be flat-filled.

        We work on native 512x512 tiles of the page: every stroke that
        falls inside a tile is merged into that tile's mask, so one LaMa
        pass repairs a whole tile and the thin strokes stay sharp.
        """
        h, w = image.shape[:2]
        # collect the strokes that still need LaMa, in page coordinates
        pending = np.zeros((h, w), np.uint8)
        for b, rest in lama_blocks:
            region = pending[b.y1:b.y2, b.x1:b.x2]
            np.maximum(region, (rest > 0).astype(np.uint8) * 255, out=region)
        if not pending.any():
            return

        # 512x512 tiles.  Tiles are used exactly once (no overlap) so we
        # do not pay for the same area twice.
        ys = list(range(0, max(1, h - LAMA_SIZE + 1), LAMA_SIZE))
        if not ys or ys[-1] + LAMA_SIZE < h:
            ys.append(max(0, h - LAMA_SIZE))
        xs = list(range(0, max(1, w - LAMA_SIZE + 1), LAMA_SIZE))
        if not xs or xs[-1] + LAMA_SIZE < w:
            xs.append(max(0, w - LAMA_SIZE))

        # Collect the tiles that need work, then run them in parallel:
        # onnxruntime releases the GIL, so threads really do help.
        jobs = []
        for ty in ys:
            for tx in xs:
                ty2 = min(h, ty + LAMA_SIZE)
                tx2 = min(w, tx + LAMA_SIZE)
                sub = pending[ty:ty2, tx:tx2]
                if not sub.any():
                    continue
                # a tile that is nearly all strokes gives LaMa no context
                if (sub > 0).mean() > 0.92:
                    continue
                jobs.append((ty, tx, ty2, tx2, sub))

        if not jobs:
            return
        tiles = [image[ty:ty2, tx:tx2] for ty, tx, ty2, tx2, _ in jobs]
        masks = [sub for _, _, _, _, sub in jobs]
        with ThreadPoolExecutor(max_workers=self.workers) as ex:
            painted = list(ex.map(self._lama_one, tiles, masks))
        for (ty, tx, ty2, tx2, sub), p in zip(jobs, painted):
            region = image[ty:ty2, tx:tx2]
            m3 = (sub > 0)[:, :, None]
            image[ty:ty2, tx:tx2] = np.where(m3, p, region)

    def _lama_one(self, crop, local_mask):
        ch, cw = crop.shape[:2]
        if ch < 8 or cw < 8:
            return crop.copy()
        rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
        img_r = cv2.resize(rgb, (LAMA_SIZE, LAMA_SIZE), interpolation=cv2.INTER_AREA)
        m_r = cv2.resize(local_mask, (LAMA_SIZE, LAMA_SIZE), interpolation=cv2.INTER_NEAREST)
        img_blob = img_r.astype(np.float32).transpose(2, 0, 1)[None]
        mask_blob = (m_r > 127).astype(np.float32)[None, None]
        out = self.session.run(None, {
            self.image_input: img_blob,
            self.mask_input: mask_blob,
        })[0]
        painted = np.clip(out[0].transpose(1, 2, 0), 0, 255).astype(np.uint8)
        painted = cv2.cvtColor(painted, cv2.COLOR_RGB2BGR)
        return cv2.resize(painted, (cw, ch), interpolation=cv2.INTER_AREA)
