"""The comic lettering removal pipeline.

Stages
------
1.  Localise lettering with the segmentation network (soft masks).
2.  For each detection, decide the ink polarity and recover the exact
    strokes inside it.
3.  Merge the strokes into one erase mask and rebuild the image.
"""
import numpy as np
import cv2

from app.detector.text_segmenter import TextSegmenter
from app.detector.regions import BubbleDetector
from app.detector.ink import (stroke_response, keep_letter_like,
                              drop_background_blobs, dilate, expand_antialias,
                              REGION_LEVEL)
from app.inpaint.inpainter import LamaInpainter


class TextBlock:
    """A coherent group of lettering plus the strokes that must be erased."""

    __slots__ = ("x1", "y1", "x2", "y2", "strokes")

    def __init__(self, x1, y1, x2, y2, strokes):
        self.x1, self.y1, self.x2, self.y2 = x1, y1, x2, y2
        self.strokes = strokes

    @property
    def width(self):
        return self.x2 - self.x1

    @property
    def height(self):
        return self.y2 - self.y1


class Cleaner:
    def __init__(self, models, seg_conf=0.25, bubble_conf=0.25, threads=4):
        self.seg = TextSegmenter(models["text_segmenter"], seg_conf, threads)
        self.bub = BubbleDetector(models["bubble_yolo"], bubble_conf, threads)
        self.inp = LamaInpainter(models["lama"], threads)

    # ------------------------------------------------------------------ API
    def clean(self, image: np.ndarray) -> np.ndarray:
        blocks = self.find_blocks(image)
        if not blocks:
            return image.copy()
        return self.inp.inpaint_blocks(image, blocks)

    def lettering_mask(self, image: np.ndarray) -> np.ndarray:
        h, w = image.shape[:2]
        out = np.zeros((h, w), np.uint8)
        for b in self.find_blocks(image):
            out[b.y1:b.y2, b.x1:b.x2] |= b.strokes
        if not out.any():
            return out
        return (dilate(out, 1) * 255).astype(np.uint8)

    # ------------------------------------------------------------- blocking
    def find_blocks(self, image: np.ndarray):
        """Find the lettering and the strokes that have to be erased."""
        h, w = image.shape[:2]
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        dets = self.seg.detect(image)
        if not dets:
            return []

        strokes_full = np.zeros((h, w), np.uint8)
        for d in dets:
            if d.mask.shape[0] < 4 or d.mask.shape[1] < 4:
                continue
            if d.mask.max() < 0.25:
                continue
            # work inside the detection box; the box border is the local
            # ground and is used to estimate the background level
            x1 = max(0, d.x1); y1 = max(0, d.y1)
            x2 = min(w, d.x2); y2 = min(h, d.y2)
            if x2 - x1 < 4 or y2 - y1 < 4:
                continue
            sub_gray = gray[y1:y2, x1:x2]
            sub_mask = np.zeros(sub_gray.shape, np.float32)
            sx1 = max(d.x1, x1); sy1 = max(d.y1, y1)
            sx2 = min(d.x2, x2); sy2 = min(d.y2, y2)
            if sx2 <= sx1 or sy2 <= sy1:
                continue
            sub_mask[sy1 - y1:sy2 - y1, sx1 - x1:sx2 - x1] = (
                d.mask[sy1 - d.y1:sy2 - d.y1, sx1 - d.x1:sx2 - d.x1])
            # The network mask bounds the search so neighbouring art cannot
            # influence the ink/ground split.
            region = sub_mask > REGION_LEVEL
            if region.sum() < 12:
                continue
            strokes = stroke_response(sub_gray, region, sub_mask)
            strokes = drop_background_blobs(strokes, region)
            strokes = keep_letter_like(strokes, region)
            if not strokes.any():
                continue
            strokes_full[y1:y2, x1:x2] |= strokes

        if not strokes_full.any():
            return []

        # grow the strokes over the anti-aliased fringe so no faint ghost
        # of a letter is left behind
        strokes_full = expand_antialias(strokes_full, gray, radius=2)
        strokes_full = dilate(strokes_full, 1)
        # Neighbouring detections can merge into a blob far too big to be
        # lettering (a speech balloon swallowed whole).  Drop those.
        strokes_full = drop_background_blobs(strokes_full, np.ones_like(strokes_full, bool))
        if not strokes_full.any():
            return []
        # group the strokes into text blocks for the inpainter
        n, lab, stats, _ = cv2.connectedComponentsWithStats(strokes_full, 8)
        blocks = []
        for i in range(1, n):
            x, y, cw, ch, a = stats[i]
            if a < 3:
                continue
            x1 = max(0, x - 12); y1 = max(0, y - 12)
            x2 = min(w, x + cw + 12); y2 = min(h, y + ch + 12)
            sub = (lab[y1:y2, x1:x2] == i).astype(np.uint8) * 255
            blocks.append(TextBlock(x1, y1, x2, y2, sub))
        return blocks
