# Manga translator - cleaning notes

## The three bundled models (all verified empirically)

### Preprocessing (both Ultralytics detectors)
- Fixed `[1,3,1024,1024]` float32 input.
- They expect **raw 0-255** values, NOT /255.  Feeding 0-1 collapses every
  class score to ~0, so the detectors silently return nothing.  The first
  version divided by 255 -- that is why it found no text at all.
- Letterbox to 1024x1024, pad value 114, centred.

### bubble_yolo.onnx
- Output `[1,6,21504]`: 4 bbox (cx,cy,w,h in canvas px) + 2 class scores.
- classes: `{0: text_bubble, 1: text_free}`.
- Useful as a second opinion on where text is, but it detects *text inside*
  balloons, not the balloon outline.

### text_segmenter.onnx  (YOLOv8m-seg)
- Output0 `[1,37,21504]` = 4 bbox + 1 class score + **32 mask coefficients**.
- Output1 `[1,32,256,256]` = mask prototypes.
- mask = `sigmoid(coeffs @ protos.reshape(32,-1)).reshape(-1,256,256)`;
  the 256 grid is 1/4 of the 1024 canvas, so `proto_px = canvas_px/4`.
- The prototype masks are **loose** (they cover the glyph plus background and
  sometimes a whole speech balloon), so they are only used to *localise*
  text; the exact strokes are re-derived from the pixels.

### lama.onnx
- image `[B,3,512,512]` float32, mask `[B,1,512,512]` float32 -> `[B,3,512,512]`.
- Expects **0-255** (feeding /255 gives a washed out result).
- Fixed 512x512, ~3.4 s per crop on 4 threads; ~4x faster with 4 threads
  running crops concurrently (onnxruntime releases the GIL).
- At native 512x512 it removes essentially 100% of thin strokes.  Upscaling
  a small crop to 512 blurs the strokes and leaves visible ghosts, so
  LaMa is always run on native 512x512 tiles of the page.

## The cleaning pipeline (app/)
1. `app/detector/onnx_yolo.py` - shared letterbox / tiling / NMS helpers.
2. `app/detector/text_segmenter.py` - correct YOLOv8-seg decoding.
3. `app/detector/ink.py` - recovers the exact strokes:
   * the network mask bounds the search region;
   * Otsu on the masked pixels splits ink from ground;
   * the ink is the **minority** side of the split (the ground dominates);
     regions whose "ink" would cover >62% are flat panels, not lettering;
   * the mask is grown over the anti-aliased fringe, otherwise faint
     ghosts of the letters survive.
4. `app/detector/regions.py` - bubble detector + mask helpers.
5. `app/inpaint/inpainter.py` - rebuild:
   * flat fill when the ring around a stroke is uniform (balloon interiors,
     white margins, flat skies) - exact and free;
   * LaMa on native 512x512 tiles for everything else.
6. `app/pipeline.py` - glues it together, groups strokes into text blocks.

## Known limitation
Where the segmentation network puts its mask over a large *white* balloon
interior, the Otsu split inside that region degenerates and part of the
balloon can be classified as "ink".  The blob-size filters catch the worst
of it, but a per-page polarity decision would be more robust.
