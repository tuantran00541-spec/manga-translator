"""Score cleaned pages against the original.

Text areas are located with the segmentation network (an independent text
area detector).  Inside them, "letter pixels" are the pixels that stand out
from their local background in the ORIGINAL.  We then measure

  residual - letter pixels that are still unchanged in the cleaned image
  ghost    - letter pixels that changed only slightly (a faint trace)
  art      - pixels OUTSIDE the text areas that were damaged
"""
import sys
import os
import glob
import numpy as np
import cv2

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def text_areas(image, det=None):
    """Binary mask of areas the segmenter believes contain text."""
    from app.detector.text_segmenter import TextSegmenter
    if det is None:
        det = TextSegmenter('models/text_segmenter.onnx', 0.20, 4)
    h, w = image.shape[:2]
    m = np.zeros((h, w), np.uint8)
    for d in det.detect(image):
        if d.mask.max() < 0.2:
            continue
        x1 = max(0, d.x1); y1 = max(0, d.y1)
        x2 = min(w, d.x2); y2 = min(h, d.y2)
        if x2 > x1 and y2 > y1:
            m[y1:y2, x1:x2] = 1
    return m


def letter_pixels(gray, areas):
    """Pixels inside `areas` that stand out from their local background."""
    bg = cv2.medianBlur(gray, 9)
    d = cv2.absdiff(gray, bg)
    # a letter stroke is a strong deviation; screentone is weaker
    return (d > 24) & (areas > 0)


def score(orig, out, areas):
    go = cv2.cvtColor(orig, cv2.COLOR_BGR2GRAY)
    gn = cv2.cvtColor(out, cv2.COLOR_BGR2GRAY)
    strokes = letter_pixels(go, areas)
    d = cv2.absdiff(go.astype(np.int16), gn.astype(np.int16))
    residual = strokes & (d < 20)
    ghost = strokes & (d >= 20) & (d < 55)
    outside = cv2.dilate(areas, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))) == 0
    art = outside & (d > 45)
    n = int(strokes.sum())
    return dict(
        strokes=n,
        residual_frac=float(residual.sum()) / max(1, n),
        ghost_frac=float(ghost.sum()) / max(1, n),
        art_frac=float(art.sum()) / max(1, int(outside.sum())),
        residual_px=int(residual.sum()),
        ghost_px=int(ghost.sum()),
        art_px=int(art.sum()),
    )


def main(ind, outd, limit=12):
    from app.detector.text_segmenter import TextSegmenter
    det = TextSegmenter('models/text_segmenter.onnx', 0.20, 4)
    files = sorted(glob.glob(os.path.join(ind, '*.png')))[:limit]
    rows = []
    for f in files:
        o = os.path.join(outd, os.path.basename(f))
        if not os.path.exists(o):
            continue
        a = cv2.imread(f); b = cv2.imread(o)
        if a is None or b is None or a.shape != b.shape:
            continue
        areas = text_areas(a, det)
        r = score(a, b, areas)
        r['name'] = os.path.basename(f)
        rows.append(r)
        print("%-12s residual %.4f ghost %.4f art %.5f  (strokes %d)" % (
            r['name'], r['residual_frac'], r['ghost_frac'], r['art_frac'], r['strokes']),
            flush=True)
    if not rows:
        print('no pairs'); return
    print('---')
    for k in ('residual_frac', 'ghost_frac', 'art_frac'):
        v = np.array([r[k] for r in rows])
        print('  %-16s mean %.5f  median %.5f  max %.5f' % (k, v.mean(), np.median(v), v.max()))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 12)
