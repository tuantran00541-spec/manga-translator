"""Clean every image in a folder: find its text, erase it, and write the result under the same name.

Usage:  python3 clean.py IN_DIR OUT_DIR
"""
import sys
import time
from pathlib import Path

import cv2
import numpy as np

from app.config import (
    BUBBLE_DETECTOR_MODEL, TEXT_SEGMENTER_MODEL, LAMA_MODEL,
    BUBBLE_CONF_THRESHOLD, TEXT_CONF_THRESHOLD, ONNX_THREADS,
)
from app.pipeline import Cleaner


def main(src: Path, dst: Path) -> int:
    dst.mkdir(parents=True, exist_ok=True)
    models = {
        "text_segmenter": TEXT_SEGMENTER_MODEL,
        "bubble_yolo": BUBBLE_DETECTOR_MODEL,
        "lama": LAMA_MODEL,
    }
    cleaner = Cleaner(
        models,
        seg_conf=TEXT_CONF_THRESHOLD,
        bubble_conf=BUBBLE_CONF_THRESHOLD,
        threads=ONNX_THREADS,
    )
    paths = sorted(src.glob("*.png"))
    t0 = time.time()
    for i, path in enumerate(paths, 1):
        image = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_COLOR)
        if image is None:
            print(f"[{i}/{len(paths)}] skip (unreadable) {path.name}")
            continue
        result = cleaner.clean(image)
        cv2.imwrite(str(dst / path.name), result)
        if i % 10 == 0 or i == len(paths):
            print(f"[{i}/{len(paths)}] {path.name} "
                  f"({(time.time() - t0) / i:.1f}s/img)", flush=True)
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        raise SystemExit(2)
    raise SystemExit(main(Path(sys.argv[1]), Path(sys.argv[2])))
